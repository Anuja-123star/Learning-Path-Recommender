/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'Inter', 'system-ui', 'sans-serif'],
        display: ['"Plus Jakarta Sans"', 'Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        navy: {
          50: '#f2f6fd',
          100: '#e6eefb',
          200: '#c9dcf6',
          300: '#9bc1ee',
          400: '#5e9be0',
          500: '#3a78cc',
          600: '#2a5fb0',
          700: '#234b8c',
          800: '#1d3c70',
          900: '#16294f',
          950: '#0d183a',
        },
        royal: {
          50: '#f0f6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
        lavender: {
          50: '#f8f7ff',
          100: '#efecff',
          200: '#ddd6fe',
          300: '#c4b5fd',
          400: '#a78bfa',
          500: '#8b5cf6',
          600: '#7c3aed',
          700: '#6d28d9',
          800: '#5b21b6',
          900: '#4c1d95',
        },
        ink: '#0b1220',
      },
      boxShadow: {
        soft: '0 1px 2px rgba(16, 24, 40, 0.04), 0 4px 16px rgba(16, 24, 40, 0.06)',
        card: '0 1px 3px rgba(16, 24, 40, 0.05), 0 10px 30px -12px rgba(16, 24, 40, 0.18)',
        glow: '0 0 0 1px rgba(255,255,255,0.4), 0 12px 40px -8px rgba(59, 130, 246, 0.45)',
      },
      backgroundImage: {
        'navy-gradient': 'linear-gradient(135deg, #0d183a 0%, #16294f 40%, #1d3c70 100%)',
        'royal-gradient': 'linear-gradient(135deg, #1e40af 0%, #3b82f6 100%)',
        'lavender-gradient': 'linear-gradient(135deg, #c4b5fd 0%, #a78bfa 100%)',
        'mesh': 'radial-gradient(60% 60% at 20% 10%, rgba(59,130,246,0.18) 0%, rgba(59,130,246,0) 60%), radial-gradient(50% 50% at 90% 20%, rgba(167,139,250,0.18) 0%, rgba(167,139,250,0) 60%)',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'float': {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        'pop': {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        'shimmer': {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.6s ease-out both',
        'fade-in': 'fade-in 0.5s ease-out both',
        'float': 'float 6s ease-in-out infinite',
        'pop': 'pop 0.3s ease-out both',
        'shimmer': 'shimmer 2s linear infinite',
      },
    },
  },
  plugins: [],
};
