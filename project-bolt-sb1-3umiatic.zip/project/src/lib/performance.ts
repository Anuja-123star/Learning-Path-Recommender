import type {
  PerformanceLevel,
  Subject,
  SubjectPerformance,
  Topic,
  TopicPerformance,
} from "./types";

/**
 * Classification rules (per project spec):
 *   Below 50%       -> Needs Improvement
 *   50% to 74%      -> Average
 *   75% and above   -> Strong
 */
export function classify(percentage: number): PerformanceLevel {
  if (percentage >= 75) return "strong";
  if (percentage >= 50) return "average";
  return "needs_improvement";
}

export const LEVEL_META: Record<
  PerformanceLevel,
  { label: string; short: string; color: string; bg: string; text: string; ring: string }
> = {
  strong: {
    label: "Strong",
    short: "Strong",
    color: "#16a34a",
    bg: "bg-emerald-50",
    text: "text-emerald-700",
    ring: "ring-emerald-200",
  },
  average: {
    label: "Average",
    short: "Average",
    color: "#d97706",
    bg: "bg-amber-50",
    text: "text-amber-700",
    ring: "ring-amber-200",
  },
  needs_improvement: {
    label: "Needs Improvement",
    short: "Needs Work",
    color: "#dc2626",
    bg: "bg-rose-50",
    text: "text-rose-700",
    ring: "ring-rose-200",
  },
};

export function safePercentage(obtained: number, max: number): number {
  if (!max || max <= 0) return 0;
  const pct = (obtained / max) * 100;
  if (!isFinite(pct)) return 0;
  return Math.max(0, Math.min(100, pct));
}

export function topicPerformance(
  topic: Topic,
  subjectId: string,
  subjectName: string
): TopicPerformance {
  const percentage = safePercentage(topic.marksObtained, topic.maxMarks);
  return {
    topic,
    percentage,
    level: classify(percentage),
    subjectId,
    subjectName,
  };
}

export function subjectPerformance(subject: Subject): SubjectPerformance {
  const topics = subject.topics ?? [];
  const perfs = topics.map((t) => topicPerformance(t, subject.id, subject.name));
  const percentage =
    perfs.length === 0
      ? 0
      : perfs.reduce((sum, p) => sum + p.percentage, 0) / perfs.length;
  return {
    subject,
    percentage,
    level: classify(percentage),
    topicCount: topics.length,
    strongCount: perfs.filter((p) => p.level === "strong").length,
    averageCount: perfs.filter((p) => p.level === "average").length,
    weakCount: perfs.filter((p) => p.level === "needs_improvement").length,
  };
}

export function allTopicPerformances(subjects: Subject[]): TopicPerformance[] {
  return subjects.flatMap((s) =>
    (s.topics ?? []).map((t) => topicPerformance(t, s.id, s.name))
  );
}

export function averageScore(subjects: Subject[]): number {
  const perfs = subjects.map(subjectPerformance);
  if (perfs.length === 0) return 0;
  return perfs.reduce((sum, p) => sum + p.percentage, 0) / perfs.length;
}

export function learningProgress(subjects: Subject[]): number {
  const topics = subjects.flatMap((s) => s.topics ?? []);
  if (topics.length === 0) return 0;
  const done = topics.filter((t) => t.completed).length;
  return (done / topics.length) * 100;
}

export function uid(prefix = "id"): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-4)}`;
}
