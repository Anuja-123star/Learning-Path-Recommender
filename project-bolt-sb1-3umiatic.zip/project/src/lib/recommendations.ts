import type { Recommendation, Subject, TopicPerformance } from "./types";
import { allTopicPerformances, classify, subjectPerformance } from "./performance";

/**
 * LEARNING PATH RECOMMENDATION ALGORITHM
 * -------------------------------------
 *
 * For every topic we compute a Priority Score that tells us how urgently a
 * student should focus on that topic. The score blends two signals:
 *
 *   1. How weak the topic itself is  -> (100 - topicPercentage)
 *   2. How weak the parent subject is -> (100 - subjectPercentage)
 *
 * The weighting gives more importance to the individual topic (0.7) than to
 * the overall subject (0.3), because the topic is the unit of learning the
 * student will actually study next.
 *
 *   Priority Score = 0.7 * (100 - Topic Percentage)
 *                  + 0.3 * (100 - Subject Percentage)
 *
 * A higher score => weaker performance => higher priority to study.
 *
 * Topics are then sorted in DESCENDING order of priority score so the most
 * urgent topics appear at the top of the personalised learning path.
 *
 * Suggested activities are chosen dynamically based on the topic's
 * classification level (no hardcoded recommendation outputs):
 *
 *   - Needs Improvement (<50%): Revise fundamentals and practise basic exercises.
 *   - Average (50%-74%):        Practise intermediate questions.
 *   - Strong (>=75%):            Attempt advanced exercises and revision.
 *
 * This module is intentionally pure (no UI / storage dependencies) so it is
 * easy to test and reason about.
 */

const ACTIVITY_FOR_LEVEL: Record<string, string> = {
  needs_improvement: "Revise fundamentals and practise basic exercises.",
  average: "Practise intermediate questions.",
  strong: "Attempt advanced exercises and revision.",
};

const WEIGHT_TOPIC = 0.7;
const WEIGHT_SUBJECT = 0.3;

export function priorityScoreFor(
  topicPercentage: number,
  subjectPercentage: number
): number {
  const topicGap = 100 - topicPercentage;
  const subjectGap = 100 - subjectPercentage;
  return WEIGHT_TOPIC * topicGap + WEIGHT_SUBJECT * subjectGap;
}

function priorityClassFromScore(score: number): "High" | "Medium" | "Low" {
  // score ranges from 0 (perfect) to 100 (nothing correct).
  if (score >= 45) return "High";
  if (score >= 25) return "Medium";
  return "Low";
}

export interface ScoredTopic extends TopicPerformance {
  priorityScore: number;
}

/**
 * Compute the full personalised, sorted learning path for a set of subjects.
 * Returns recommendations sorted by priority score (descending).
 */
export function buildLearningPath(subjects: Subject[]): Recommendation[] {
  const topicPerfs = allTopicPerformances(subjects);
  const subjectPerfMap = new Map(
    subjects.map((s) => [s.id, subjectPerformance(s)])
  );

  const recommendations: Recommendation[] = topicPerfs.map((tp) => {
    const subjPerf = subjectPerfMap.get(tp.subjectId);
    const subjectPct = subjPerf?.percentage ?? 0;
    const priorityScore = priorityScoreFor(tp.percentage, subjectPct);
    const level = classify(tp.percentage);
    return {
      topicPerformance: tp,
      subjectPercentage: subjectPct,
      priorityScore: Math.round(priorityScore * 10) / 10,
      priorityClass: priorityClassFromScore(priorityScore),
      suggestedActivity: ACTIVITY_FOR_LEVEL[level] ?? ACTIVITY_FOR_LEVEL.average,
    };
  });

  recommendations.sort((a, b) => b.priorityScore - a.priorityScore);
  return recommendations;
}

/**
 * Quick summary used by the dashboard's "Recommended Next Steps" panel:
 * returns the top N topics the student should focus on next.
 */
export function topRecommendations(
  subjects: Subject[],
  limit = 5
): Recommendation[] {
  return buildLearningPath(subjects)
    .filter((r) => !r.topicPerformance.topic.completed)
    .slice(0, limit);
}
