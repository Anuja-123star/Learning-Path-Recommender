import type { Student, StudentRecord, Subject } from "./types";
import { buildDemoSubjects } from "./demoData";

/**
 * LocalStorage-backed persistence layer for the demo.
 *
 * Keys:
 *   lpr:students   -> Student[]
 *   lpr:session    -> Student.id (current logged-in student)
 *   lpr:record:<id> -> StudentRecord { subjects, completedTopicIds }
 *
 * NOTE: This is demo-only persistence as required by the project spec.
 * Passwords are stored in plaintext for the demo — this is NOT safe for
 * real production usage.
 */

const K_STUDENTS = "lpr:students";
const K_SESSION = "lpr:session";
const K_RECORD = (id: string) => `lpr:record:${id}`;

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore quota errors in demo */
  }
}

// ---- Students ----

export function getStudents(): Student[] {
  return read<Student[]>(K_STUDENTS, []);
}

export function saveStudents(students: Student[]): void {
  write(K_STUDENTS, students);
}

export function findStudentByEmail(email: string): Student | undefined {
  return getStudents().find(
    (s) => s.email.toLowerCase() === email.trim().toLowerCase()
  );
}

export function addStudent(student: Student): void {
  const all = getStudents();
  all.push(student);
  saveStudents(all);
}

// ---- Session ----

export function getSessionId(): string | null {
  return read<string | null>(K_SESSION, null);
}

export function setSession(id: string | null): void {
  if (id) write(K_SESSION, id);
  else localStorage.removeItem(K_SESSION);
}

// ---- Records (subjects + progress) ----

export function getRecord(studentId: string): StudentRecord {
  return read<StudentRecord>(K_RECORD(studentId), {
    subjects: [],
    completedTopicIds: [],
  });
}

export function saveRecord(studentId: string, record: StudentRecord): void {
  write(K_RECORD(studentId), record);
}

export function getSubjectsFor(studentId: string): Subject[] {
  return getRecord(studentId).subjects;
}

export function saveSubjectsFor(studentId: string, subjects: Subject[]): void {
  const rec = getRecord(studentId);
  rec.subjects = subjects;
  saveRecord(studentId, rec);
}
