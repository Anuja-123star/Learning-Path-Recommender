import type { Resource, Subject } from "./types";
import { DEMO_RESOURCES } from "./demoData";

const TYPE_META: Record<
  Resource["type"],
  { label: string; color: string; bg: string; ring: string }
> = {
  tutorial: {
    label: "Tutorial",
    color: "text-royal-700",
    bg: "bg-royal-50",
    ring: "ring-royal-200",
  },
  notes: {
    label: "Revision Notes",
    color: "text-lavender-700",
    bg: "bg-lavender-50",
    ring: "ring-lavender-200",
  },
  practice: {
    label: "Practice Questions",
    color: "text-emerald-700",
    bg: "bg-emerald-50",
    ring: "ring-emerald-200",
  },
  activity: {
    label: "Learning Activity",
    color: "text-amber-700",
    bg: "bg-amber-50",
    ring: "ring-amber-200",
  },
};

export function resourceTypeMeta(type: Resource["type"]) {
  return TYPE_META[type];
}

/**
 * Returns resources relevant to the student's current subjects/topics.
 * Matches on subject name and topic name; if a topic-specific match exists
 * it is shown first, otherwise subject-level resources are included.
 */
export function resourcesForSubjects(subjects: Subject[]): {
  byTopic: Record<string, Resource[]>;
  all: Resource[];
} {
  const topicKeys = new Set<string>();
  const subjectNames = new Set<string>();
  subjects.forEach((s) => {
    subjectNames.add(s.name.trim().toLowerCase());
    s.topics.forEach((t) => topicKeys.add(t.name.trim().toLowerCase()));
  });

  const all = DEMO_RESOURCES.filter((r) => {
    const subjMatch = subjectNames.has(r.subject.trim().toLowerCase());
    const topicMatch = topicKeys.has(r.topic.trim().toLowerCase());
    return subjMatch || topicMatch;
  });

  const byTopic: Record<string, Resource[]> = {};
  all.forEach((r) => {
    const key = `${r.subject}::${r.topic}`;
    (byTopic[key] ??= []).push(r);
  });

  return { byTopic, all };
}

export function resourcesForTopic(subjectName: string, topicName: string): Resource[] {
  const subj = subjectName.trim().toLowerCase();
  const top = topicName.trim().toLowerCase();
  const direct = DEMO_RESOURCES.filter(
    (r) =>
      r.subject.trim().toLowerCase() === subj &&
      r.topic.trim().toLowerCase() === top
  );
  if (direct.length) return direct;
  // fallback: subject-level resources
  return DEMO_RESOURCES.filter(
    (r) => r.subject.trim().toLowerCase() === subj
  );
}
