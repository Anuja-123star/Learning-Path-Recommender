import type { Resource, Subject } from "./types";
import { uid } from "./performance";

/**
 * Demo seed data used for the "Try demo account" login flow and as a starting
 * point for any brand-new account that wants example subjects to explore.
 */

export function buildDemoSubjects(): Subject[] {
  const now = Date.now();
  const mk = (name: string, topics: Array<[string, number, number, boolean?]>): Subject => ({
    id: uid("subj"),
    name,
    createdAt: now,
    topics: topics.map(([tName, marks, max, done]) => ({
      id: uid("topic"),
      name: tName,
      marksObtained: marks,
      maxMarks: max,
      completed: done ?? false,
      createdAt: now,
    })),
  });

  return [
    mk("Data Structures & Algorithms", [
      ["Arrays & Strings", 88, 100, true],
      ["Linked Lists", 72, 100, true],
      ["Stacks & Queues", 64, 100, false],
      ["Trees & BST", 45, 100, false],
      ["Graphs", 38, 100, false],
      ["Dynamic Programming", 30, 100, false],
    ]),
    mk("Operating Systems", [
      ["Process Management", 80, 100, true],
      ["CPU Scheduling", 66, 100, false],
      ["Memory Management", 58, 100, false],
      ["File Systems", 44, 100, false],
      ["Deadlocks", 50, 100, false],
    ]),
    mk("Database Management Systems", [
      ["ER Models", 90, 100, true],
      ["SQL & Joins", 78, 100, true],
      ["Normalization", 62, 100, false],
      ["Transactions & Concurrency", 48, 100, false],
      ["Indexing", 35, 100, false],
    ]),
    mk("Computer Networks", [
      ["OSI Model", 82, 100, true],
      ["TCP/IP", 70, 100, false],
      ["Routing Algorithms", 52, 100, false],
      ["Application Protocols", 40, 100, false],
    ]),
  ];
}

/**
 * Sample learning resources organised by subject and topic names that match
 * the demo data. These are illustrative links to free, well-known educational
 * material (YouTube tutorials, MDN, GeeksforGeeks-style references).
 */
export const DEMO_RESOURCES: Resource[] = [
  // DSA
  {
    id: "r1",
    title: "Arrays & Strings — Crash Course",
    type: "tutorial",
    topic: "Arrays & Strings",
    subject: "Data Structures & Algorithms",
    description: "A visual walkthrough of array operations and string manipulation fundamentals.",
    url: "https://www.youtube.com/watch?v=QJ20NXQ0gQ0",
    duration: "18 min",
  },
  {
    id: "r2",
    title: "Linked Lists Explained Visually",
    type: "tutorial",
    topic: "Linked Lists",
    subject: "Data Structures & Algorithms",
    description: "Pointers, traversal, insertion and deletion with animated diagrams.",
    url: "https://www.youtube.com/watch?v=Hj_rA0dhrUk",
    duration: "22 min",
  },
  {
    id: "r3",
    title: "Graphs — Revision Notes",
    type: "notes",
    topic: "Graphs",
    subject: "Data Structures & Algorithms",
    description: "BFS, DFS, representations, and common graph problems in one sheet.",
    url: "https://www.geeksforgeeks.org/graph-data-structure-and-algorithms/",
    duration: "12 min read",
  },
  {
    id: "r4",
    title: "Dynamic Programming Practice Set",
    type: "practice",
    topic: "Dynamic Programming",
    subject: "Data Structures & Algorithms",
    description: "20 graded DP problems from 1D to 2D with editorial hints.",
    url: "https://leetcode.com/studyplan/dynamic-programming/",
    duration: "Self-paced",
  },
  // OS
  {
    id: "r5",
    title: "CPU Scheduling Algorithms",
    type: "tutorial",
    topic: "CPU Scheduling",
    subject: "Operating Systems",
    description: "FCFS, SJF, Round Robin and Priority scheduling with worked examples.",
    url: "https://www.youtube.com/watch?v=EWkQ8nUgXpM",
    duration: "25 min",
  },
  {
    id: "r6",
    title: "Deadlocks — Notes & Activity",
    type: "activity",
    topic: "Deadlocks",
    subject: "Operating Systems",
    description: "Detection, prevention, avoidance and a banker's algorithm worksheet.",
    url: "https://www.geeksforgeeks.org/deadlock-prevention/",
    duration: "15 min",
  },
  // DBMS
  {
    id: "r7",
    title: "Normalization Step by Step",
    type: "notes",
    topic: "Normalization",
    subject: "Database Management Systems",
    description: "1NF to BCNF with examples and anomaly explanations.",
    url: "https://www.geeksforgeeks.org/normal-forms-in-dbms/",
    duration: "14 min read",
  },
  {
    id: "r8",
    title: "Transactions & Concurrency Control",
    type: "tutorial",
    topic: "Transactions & Concurrency",
    subject: "Database Management Systems",
    description: "ACID, isolation levels, locking and MVVM explained simply.",
    url: "https://www.youtube.com/watch?v=2WcBG1M5LbU",
    duration: "20 min",
  },
  // Networks
  {
    id: "r9",
    title: "Routing Algorithms — Distance Vector",
    type: "tutorial",
    topic: "Routing Algorithms",
    subject: "Computer Networks",
    description: "Dijkstra and Bellman-Ford routing with network examples.",
    url: "https://www.youtube.com/watch?v=5E2M0x7wQ3E",
    duration: "17 min",
  },
  {
    id: "r10",
    title: "Application Protocols — HTTP, DNS, FTP",
    type: "notes",
    topic: "Application Protocols",
    subject: "Computer Networks",
    description: "A concise reference sheet for common application-layer protocols.",
    url: "https://www.geeksforgeeks.org/application-layer-protocols/",
    duration: "10 min read",
  },
];

export const COURSE_OPTIONS = [
  "Computer Science & Engineering",
  "Information Technology",
  "Electronics & Communication",
  "Artificial Intelligence",
  "Data Science",
  "Software Engineering",
];
