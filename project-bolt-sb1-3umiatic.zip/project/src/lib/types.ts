// Core domain types for the Learning Path Recommender app.

export type PerformanceLevel = "needs_improvement" | "average" | "strong";

export interface Topic {
  id: string;
  name: string;
  marksObtained: number;
  maxMarks: number;
  completed: boolean; // whether the student has marked this topic as learned
  createdAt: number;
}

export interface Subject {
  id: string;
  name: string;
  topics: Topic[];
  createdAt: number;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  password: string; // demo-only, plaintext in localStorage (NOT production-safe)
  course: string;
  createdAt: number;
}

export interface StudentRecord {
  subjects: Subject[];
  completedTopicIds: string[];
}

// ----- Derived / computed types -----

export interface TopicPerformance {
  topic: Topic;
  percentage: number;
  level: PerformanceLevel;
  subjectId: string;
  subjectName: string;
}

export interface SubjectPerformance {
  subject: Subject;
  percentage: number;
  level: PerformanceLevel;
  topicCount: number;
  strongCount: number;
  averageCount: number;
  weakCount: number;
}

export interface Recommendation {
  topicPerformance: TopicPerformance;
  subjectPercentage: number;
  priorityScore: number;
  priorityClass: "High" | "Medium" | "Low";
  suggestedActivity: string;
}

export interface Resource {
  id: string;
  title: string;
  type: "tutorial" | "notes" | "practice" | "activity";
  topic: string; // topic name to match
  subject: string; // subject name to match
  description: string;
  url: string;
  duration: string;
}
