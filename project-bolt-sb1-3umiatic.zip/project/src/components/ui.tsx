import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";

export function StatCard({
  icon: Icon,
  label,
  value,
  hint,
  accent = "royal",
}: {
  icon: LucideIcon;
  label: string;
  value: ReactNode;
  hint?: string;
  accent?: "royal" | "navy" | "lavender" | "emerald" | "amber" | "rose";
}) {
  const accents: Record<string, string> = {
    royal: "from-royal-500/15 to-royal-500/5 text-royal-700 ring-royal-100",
    navy: "from-navy-700/15 to-navy-700/5 text-navy-800 ring-navy-100",
    lavender: "from-lavender-400/15 to-lavender-400/5 text-lavender-700 ring-lavender-200",
    emerald: "from-emerald-500/15 to-emerald-500/5 text-emerald-700 ring-emerald-100",
    amber: "from-amber-500/15 to-amber-500/5 text-amber-700 ring-amber-100",
    rose: "from-rose-500/15 to-rose-500/5 text-rose-700 ring-rose-100",
  };
  return (
    <div className="card-elevated group relative overflow-hidden p-5 transition-transform duration-300 hover:-translate-y-0.5">
      <div className={`mb-4 inline-flex rounded-xl bg-gradient-to-br p-2.5 ring-1 ${accents[accent]}`}>
        <Icon className="h-5 w-5" />
      </div>
      <p className="text-sm font-medium text-navy-500">{label}</p>
      <p className="mt-1 text-2xl font-bold text-navy-900">{value}</p>
      {hint && <p className="mt-1 text-xs text-navy-400">{hint}</p>}
    </div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  center,
}: {
  eyebrow?: string;
  title: ReactNode;
  description?: ReactNode;
  center?: boolean;
}) {
  return (
    <div className={`${center ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}`}>
      {eyebrow && <span className="section-eyebrow">{eyebrow}</span>}
      <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-navy-900 sm:text-4xl">
        {title}
      </h2>
      {description && (
        <p className="mt-3 text-base leading-relaxed text-navy-500">{description}</p>
      )}
    </div>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="card-elevated flex flex-col items-center justify-center gap-3 px-6 py-14 text-center">
      <div className="grid h-14 w-14 place-items-center rounded-2xl bg-navy-50 text-royal-600 ring-1 ring-navy-100">
        <Icon className="h-7 w-7" />
      </div>
      <h3 className="text-lg font-bold text-navy-900">{title}</h3>
      {description && <p className="max-w-md text-sm text-navy-500">{description}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

export function PageHeader({
  title,
  subtitle,
  icon: Icon,
  actions,
}: {
  title: string;
  subtitle?: string;
  icon: LucideIcon;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-8 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
      <div className="flex items-start gap-3">
        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-navy-gradient text-white shadow-soft">
          <Icon className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-navy-900 sm:text-3xl">
            {title}
          </h1>
          {subtitle && <p className="mt-1 text-sm text-navy-500">{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}
