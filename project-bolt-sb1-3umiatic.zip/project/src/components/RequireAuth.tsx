import { Navigate } from "@/components/Navigate";
import { useApp } from "@/context/AppContext";
import type { ReactNode } from "react";

/** Wraps app pages: redirects to login if not authenticated. */
export function RequireAuth({ children }: { children: ReactNode }) {
  const { student } = useApp();
  if (!student) return <Navigate to="/login" />;
  return <>{children}</>;
}
