import { Compass, Github, GraduationCap, Heart, Mail, Route } from "lucide-react";
import { useApp } from "@/context/AppContext";

export function Footer() {
  const { navigate } = useApp();
  return (
    <footer className="relative overflow-hidden bg-navy-gradient text-white">
      <div className="absolute inset-0 grid-pattern opacity-40" />
      <div className="container-page relative py-14">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/15 ring-1 ring-white/20">
                <Route className="h-5 w-5" />
              </span>
              <div className="leading-none">
                <p className="text-base font-extrabold">Learning Path Recommender</p>
                <p className="text-xs font-medium uppercase tracking-[0.18em] text-lavender-200">
                  Personalised academic guidance
                </p>
              </div>
            </div>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-navy-100">
              An educational web application that analyses academic performance and
              generates personalised learning paths so students can study smarter —
              focusing on the topics that need the most attention.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <span className="chip bg-white/10 text-navy-50 ring-1 ring-white/15">
                <GraduationCap className="h-3.5 w-3.5" /> CS Engineering Project
              </span>
              <span className="chip bg-white/10 text-navy-50 ring-1 ring-white/15">
                <Compass className="h-3.5 w-3.5" /> Rule-Based Recommendations
              </span>
            </div>
          </div>

          <div>
            <p className="text-sm font-semibold text-white">Platform</p>
            <ul className="mt-3 space-y-2 text-sm text-navy-100">
              <li><button onClick={() => navigate("/#features")} className="hover:text-white">Features</button></li>
              <li><button onClick={() => navigate("/#how")} className="hover:text-white">How It Works</button></li>
              <li><button onClick={() => navigate("/#about")} className="hover:text-white">About</button></li>
              <li><button onClick={() => navigate("/register")} className="hover:text-white">Get Started</button></li>
            </ul>
          </div>

          <div>
            <p className="text-sm font-semibold text-white">Account</p>
            <ul className="mt-3 space-y-2 text-sm text-navy-100">
              <li><button onClick={() => navigate("/login")} className="hover:text-white">Login</button></li>
              <li><button onClick={() => navigate("/register")} className="hover:text-white">Create Account</button></li>
              <li><button onClick={() => navigate("/login")} className="hover:text-white">Try Demo</button></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-navy-200 sm:flex-row">
          <p>© {new Date().getFullYear()} Learning Path Recommender. Built for an academic demonstration.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" /> demo@learningpath.app</span>
            <span className="flex items-center gap-1.5"><Github className="h-3.5 w-3.5" /> React · TypeScript · Tailwind</span>
            <span className="flex items-center gap-1.5">Made with <Heart className="h-3.5 w-3.5 text-rose-300" /></span>
          </div>
        </div>
      </div>
    </footer>
  );
}
