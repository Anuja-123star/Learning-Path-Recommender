import { useApp } from "@/context/AppContext";
import { useEffect } from "react";

/** Lightweight hash-based navigation helper. */
export function Navigate({ to }: { to: string }) {
  const { navigate } = useApp();
  useEffect(() => {
    navigate(to);
  }, [to, navigate]);
  return null;
}
