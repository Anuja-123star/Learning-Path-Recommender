import type { ReactNode } from "react";

/**
 * Tiny dependency-free chart components built with inline SVG.
 * They animate on mount and are styled to match the navy/royal/lavender theme.
 */

// ----- Donut chart (single percentage) -----

export function Donut({
  value,
  size = 120,
  stroke = 12,
  color = "#2563eb",
  trackColor = "#e6eefb",
  label,
  sublabel,
}: {
  value: number; // 0..100
  size?: number;
  stroke?: number;
  color?: string;
  trackColor?: string;
  label?: string;
  sublabel?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, value));
  const offset = c - (clamped / 100) * c;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={trackColor} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1s cubic-bezier(0.22, 1, 0.36, 1)" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-2xl font-bold text-navy-900">{label ?? `${Math.round(clamped)}%`}</span>
        {sublabel && <span className="text-[11px] font-medium text-navy-400">{sublabel}</span>}
      </div>
    </div>
  );
}

// ----- Horizontal progress bar -----

export function ProgressBar({
  value,
  color = "#2563eb",
  height = 10,
  trackColor = "#e6eefb",
  showLabel = false,
}: {
  value: number;
  color?: string;
  height?: number;
  trackColor?: string;
  showLabel?: boolean;
}) {
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div className="w-full">
      <div className="w-full overflow-hidden rounded-full" style={{ height, background: trackColor }}>
        <div
          className="h-full rounded-full transition-[width] duration-700 ease-out"
          style={{ width: `${clamped}%`, background: color }}
        />
      </div>
      {showLabel && (
        <div className="mt-1 text-right text-xs font-semibold text-navy-500">{Math.round(clamped)}%</div>
      )}
    </div>
  );
}

// ----- Vertical bar chart (subject-wise performance) -----

export function BarChart({
  data,
  height = 220,
}: {
  data: { label: string; value: number; color?: string }[];
  height?: number;
}) {
  const max = 100;
  const barW = 38;
  const gap = 18;
  const width = data.length * (barW + gap) + gap;
  return (
    <div className="w-full overflow-x-auto scrollbar-thin">
      <svg width={Math.max(width, 100)} height={height} role="img" aria-label="Subject-wise performance chart">
        {[0, 25, 50, 75, 100].map((g) => {
          const y = height - 24 - (g / max) * (height - 48);
          return (
            <g key={g}>
              <line x1={0} x2={Math.max(width, 100)} y1={y} y2={y} stroke="#eef2f7" strokeWidth={1} />
              <text x={2} y={y - 4} fontSize={9} fill="#94a3b8">
                {g}
              </text>
            </g>
          );
        })}
        {data.map((d, i) => {
          const x = gap + i * (barW + gap);
          const h = (d.value / max) * (height - 48);
          const y = height - 24 - h;
          const color = d.color ?? "#2563eb";
          return (
            <g key={i} style={{ animation: `fade-up 0.6s ease-out ${i * 0.06}s both` }}>
              <rect x={x} y={y} width={barW} height={h} rx={6} fill={color} opacity={0.9}>
                <title>{`${d.label}: ${Math.round(d.value)}%`}</title>
              </rect>
              <text x={x + barW / 2} y={y - 6} textAnchor="middle" fontSize={10} fontWeight={600} fill="#1d3c70">
                {Math.round(d.value)}
              </text>
              <text x={x + barW / 2} y={height - 8} textAnchor="middle" fontSize={9.5} fill="#475569">
                {truncate(d.label, 14)}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

// ----- Radar chart (strength across subjects) -----

export function RadarChart({
  axes,
  values,
  size = 260,
  color = "#2563eb",
}: {
  axes: string[];
  values: number[]; // 0..100, same length as axes
  size?: number;
  color?: string;
}) {
  const cx = size / 2;
  const cy = size / 2;
  const r = size / 2 - 36;
  const n = axes.length;
  const angle = (i: number) => (Math.PI * 2 * i) / n - Math.PI / 2;
  const point = (i: number, radius: number) => [
    cx + Math.cos(angle(i)) * radius,
    cy + Math.sin(angle(i)) * radius,
  ];
  const rings = [0.25, 0.5, 0.75, 1];

  const dataPath = values
    .map((v, i) => {
      const [px, py] = point(i, (Math.max(0, Math.min(100, v)) / 100) * r);
      return `${px},${py}`;
    })
    .join(" ");

  return (
    <svg width={size} height={size} role="img" aria-label="Strength radar chart">
      {rings.map((rr, idx) => (
        <polygon
          key={idx}
          points={axes.map((_, i) => point(i, r * rr).join(",")).join(" ")}
          fill="none"
          stroke="#e6eefb"
          strokeWidth={1}
        />
      ))}
      {axes.map((_, i) => {
        const [px, py] = point(i, r);
        return (
          <line key={i} x1={cx} y1={cy} x2={px} y2={py} stroke="#e6eefb" strokeWidth={1} />
        );
      })}
      <polygon
        points={dataPath}
        fill={color}
        fillOpacity={0.22}
        stroke={color}
        strokeWidth={2}
        style={{ animation: "fade-in 0.8s ease-out both" }}
      />
      {values.map((v, i) => {
        const [px, py] = point(i, (Math.max(0, Math.min(100, v)) / 100) * r);
        return <circle key={i} cx={px} cy={py} r={3.5} fill={color} />;
      })}
      {axes.map((label, i) => {
        const [px, py] = point(i, r + 18);
        return (
          <text
            key={i}
            x={px}
            y={py}
            textAnchor="middle"
            dominantBaseline="middle"
            fontSize={9.5}
            fontWeight={600}
            fill="#475569"
          >
            {truncate(label, 12)}
          </text>
        );
      })}
    </svg>
  );
}

// ----- Stacked horizontal distribution (level distribution) -----

export function StackedBar({
  segments,
  height = 14,
}: {
  segments: { value: number; color: string; label: string }[];
  height?: number;
}) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  return (
    <div className="flex w-full overflow-hidden rounded-full" style={{ height, background: "#eef2f7" }}>
      {total === 0 && <div className="h-full w-full" />}
      {total > 0 &&
        segments.map((s, i) => (
          <div
            key={i}
            className="h-full transition-all duration-700"
            style={{
              width: `${(s.value / total) * 100}%`,
              background: s.color,
            }}
            title={`${s.label}: ${s.value}`}
          />
        ))}
    </div>
  );
}

function truncate(s: string, n: number): string {
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}

// ----- Legend -----

export function ChartLegend({ items }: { items: { color: string; label: string }[] }): ReactNode {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
      {items.map((it, i) => (
        <div key={i} className="flex items-center gap-2 text-xs font-medium text-navy-500">
          <span className="h-2.5 w-2.5 rounded-full" style={{ background: it.color }} />
          {it.label}
        </div>
      ))}
    </div>
  );
}
