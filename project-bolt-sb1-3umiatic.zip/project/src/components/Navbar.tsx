import { useEffect, useState } from "react";
import {
  Compass,
  LayoutDashboard,
  ListChecks,
  LogIn,
  LogOut,
  Menu,
  NotebookPen,
  Route,
  Sparkles,
  TrendingUp,
  UserPlus,
  X,
  BookOpen,
  BarChart3,
  Library,
} from "lucide-react";
import { useApp } from "@/context/AppContext";

const PUBLIC_LINKS = [
  { label: "Home", to: "/", icon: Compass },
  { label: "Features", to: "/#features", icon: Sparkles },
  { label: "How It Works", to: "/#how", icon: Route },
  { label: "About", to: "/#about", icon: BookOpen },
];

const APP_LINKS = [
  { label: "Dashboard", to: "/app", icon: LayoutDashboard },
  { label: "Performance", to: "/app/performance", icon: NotebookPen },
  { label: "Analysis", to: "/app/analysis", icon: BarChart3 },
  { label: "Learning Path", to: "/app/path", icon: Route },
  { label: "Resources", to: "/app/resources", icon: Library },
  { label: "Progress", to: "/app/progress", icon: ListChecks },
];

function Logo({ onClick }: { onClick: () => void }) {
  return (
    <button onClick={onClick} className="group flex items-center gap-2.5">
      <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-navy-gradient text-white shadow-glow">
        <Route className="h-5 w-5" strokeWidth={2.4} />
        <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-lavender-400 ring-2 ring-white" />
      </span>
      <span className="flex flex-col items-start leading-none">
        <span className="text-[15px] font-extrabold tracking-tight text-navy-900">
          Learning Path
        </span>
        <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-royal-600">
          Recommender
        </span>
      </span>
    </button>
  );
}

export function Navbar() {
  const { student, navigate, logout, route } = useApp();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const isApp = route.startsWith("/app");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [route]);

  const links = isApp && student ? APP_LINKS : PUBLIC_LINKS;

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/85 backdrop-blur-xl shadow-soft"
          : "bg-white/40 backdrop-blur-md"
      }`}
    >
      <nav className="container-page flex h-16 items-center justify-between gap-4">
        <Logo onClick={() => navigate(student ? "/app" : "/")} />

        <div className="hidden items-center gap-1 lg:flex">
          {links.map((l) => {
            const Icon = l.icon;
            const active =
              l.to === route ||
              (l.to === "/app" && route === "/app") ||
              (l.to.includes("#") && route === "/");
            return (
              <button
                key={l.label}
                onClick={() => navigate(l.to)}
                className={`flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-sm font-medium transition-colors ${
                  active ? "text-royal-700" : "text-navy-600 hover:text-navy-900"
                } hover:bg-navy-50`}
              >
                {isApp && <Icon className="h-4 w-4" />}
                {l.label}
              </button>
            );
          })}
        </div>

        <div className="hidden items-center gap-2 lg:flex">
          {student ? (
            <>
              <div className="flex items-center gap-2 rounded-xl bg-navy-50 px-3 py-1.5">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-navy-gradient text-xs font-bold text-white">
                  {student.name.charAt(0).toUpperCase()}
                </span>
                <span className="text-sm font-semibold text-navy-700">{student.name.split(" ")[0]}</span>
              </div>
              <button onClick={logout} className="btn-ghost px-3.5 py-2">
                <LogOut className="h-4 w-4" /> Logout
              </button>
            </>
          ) : (
            <>
              <button onClick={() => navigate("/login")} className="btn-ghost px-4 py-2.5">
                <LogIn className="h-4 w-4" /> Login
              </button>
              <button onClick={() => navigate("/register")} className="btn-primary px-4 py-2.5">
                <UserPlus className="h-4 w-4" /> Get Started
              </button>
            </>
          )}
        </div>

        <button
          onClick={() => setOpen((v) => !v)}
          className="grid h-10 w-10 place-items-center rounded-xl ring-1 ring-navy-200 lg:hidden"
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-navy-100 bg-white lg:hidden">
          <div className="container-page flex flex-col gap-1 py-4">
            {links.map((l) => {
              const Icon = l.icon;
              return (
                <button
                  key={l.label}
                  onClick={() => navigate(l.to)}
                  className="flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-left text-sm font-medium text-navy-700 hover:bg-navy-50"
                >
                  <Icon className="h-4 w-4 text-royal-600" />
                  {l.label}
                </button>
              );
            })}
            <div className="mt-2 flex gap-2 border-t border-navy-100 pt-3">
              {student ? (
                <button onClick={logout} className="btn-ghost flex-1">
                  <LogOut className="h-4 w-4" /> Logout
                </button>
              ) : (
                <>
                  <button onClick={() => navigate("/login")} className="btn-ghost flex-1">
                    <LogIn className="h-4 w-4" /> Login
                  </button>
                  <button onClick={() => navigate("/register")} className="btn-primary flex-1">
                    <UserPlus className="h-4 w-4" /> Get Started
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
