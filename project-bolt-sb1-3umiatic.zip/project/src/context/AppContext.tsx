import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { Student, Subject } from "@/lib/types";
import {
  addStudent,
  findStudentByEmail,
  getStudents,
  getSessionId,
  getSubjectsFor,
  saveSubjectsFor,
  saveStudents,
  setSession,
} from "@/lib/storage";
import { buildDemoSubjects } from "@/lib/demoData";
import { uid } from "@/lib/performance";

interface AppContextValue {
  student: Student | null;
  subjects: Subject[];
  route: string;
  navigate: (to: string) => void;
  login: (email: string, password: string) => { ok: boolean; error?: string };
  loginDemo: () => void;
  register: (data: {
    name: string;
    email: string;
    password: string;
    course: string;
  }) => { ok: boolean; error?: string };
  logout: () => void;
  setSubjects: (subjects: Subject[]) => void;
  loadDemoData: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

function currentPath(): string {
  return window.location.hash.replace(/^#/, "") || "/";
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [student, setStudent] = useState<Student | null>(null);
  const [subjects, setSubjectsState] = useState<Subject[]>([]);
  const [route, setRoute] = useState<string>(currentPath());

  // Restore session on mount.
  useEffect(() => {
    const sid = getSessionId();
    if (sid) {
      const found = getStudents().find((s) => s.id === sid);
      if (found) {
        setStudent(found);
        setSubjectsState(getSubjectsFor(sid));
      } else {
        setSession(null);
      }
    }
    const onHash = () => setRoute(currentPath());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navigate = useCallback((to: string) => {
    window.location.hash = to;
    setRoute(to);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const persistSubjects = useCallback(
    (next: Subject[]) => {
      setSubjectsState(next);
      if (student) saveSubjectsFor(student.id, next);
    },
    [student]
  );

  const login = useCallback((email: string, password: string) => {
    const found = findStudentByEmail(email);
    if (!found) return { ok: false, error: "No account found with that email." };
    if (found.password !== password)
      return { ok: false, error: "Incorrect password. Please try again." };
    setStudent(found);
    setSession(found.id);
    setSubjectsState(getSubjectsFor(found.id));
    return { ok: true };
  }, []);

  const loginDemo = useCallback(() => {
    const demoEmail = "demo@learningpath.app";
    let demo = findStudentByEmail(demoEmail);
    if (!demo) {
      demo = {
        id: uid("stu"),
        name: "Aarav Sharma",
        email: demoEmail,
        password: "demo1234",
        course: "Computer Science & Engineering",
        createdAt: Date.now(),
      };
      addStudent(demo);
      saveSubjectsFor(demo.id, buildDemoSubjects());
    }
    // Ensure demo account always has data to explore.
    const existing = getSubjectsFor(demo.id);
    if (existing.length === 0) saveSubjectsFor(demo.id, buildDemoSubjects());
    setStudent(demo);
    setSession(demo.id);
    setSubjectsState(getSubjectsFor(demo.id));
  }, []);

  const register = useCallback(
    (data: { name: string; email: string; password: string; course: string }) => {
      if (findStudentByEmail(data.email))
        return { ok: false, error: "An account with this email already exists." };
      const newStudent: Student = {
        id: uid("stu"),
        name: data.name.trim(),
        email: data.email.trim().toLowerCase(),
        password: data.password,
        course: data.course,
        createdAt: Date.now(),
      };
      addStudent(newStudent);
      setStudent(newStudent);
      setSession(newStudent.id);
      setSubjectsState([]);
      return { ok: true };
    },
    []
  );

  const logout = useCallback(() => {
    setStudent(null);
    setSubjectsState([]);
    setSession(null);
    navigate("/");
  }, [navigate]);

  const loadDemoData = useCallback(() => {
    if (!student) return;
    persistSubjects(buildDemoSubjects());
  }, [student, persistSubjects]);

  const value = useMemo<AppContextValue>(
    () => ({
      student,
      subjects,
      route,
      navigate,
      login,
      loginDemo,
      register,
      logout,
      setSubjects: persistSubjects,
      loadDemoData,
    }),
    [student, subjects, route, navigate, login, loginDemo, register, logout, persistSubjects, loadDemoData]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
