import { useState } from "react";
import {
  AlertCircle,
  Check,
  ChevronDown,
  Lightbulb,
  NotebookPen,
  Pencil,
  Plus,
  Save,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";
import { useApp } from "@/context/AppContext";
import { EmptyState, PageHeader } from "@/components/ui";
import { LEVEL_META, safePercentage, subjectPerformance, uid } from "@/lib/performance";
import type { Subject, Topic } from "@/lib/types";

export function PerformancePage() {
  const { subjects, setSubjects, loadDemoData, navigate } = useApp();
  const [newSubject, setNewSubject] = useState("");
  const [subjectError, setSubjectError] = useState<string | null>(null);
  const [openSubjectId, setOpenSubjectId] = useState<string | null>(null);
  const [editingTopic, setEditingTopic] = useState<{ subjectId: string; topicId: string | null } | null>(null);

  function addSubject() {
    const name = newSubject.trim();
    if (!name) {
      setSubjectError("Enter a subject name.");
      return;
    }
    if (subjects.some((s) => s.name.toLowerCase() === name.toLowerCase())) {
      setSubjectError("This subject already exists.");
      return;
    }
    const subj: Subject = { id: uid("subj"), name, topics: [], createdAt: Date.now() };
    setSubjects([...subjects, subj]);
    setNewSubject("");
    setSubjectError(null);
    setOpenSubjectId(subj.id);
  }

  function deleteSubject(id: string) {
    setSubjects(subjects.filter((s) => s.id !== id));
  }

  function updateSubject(id: string, patch: Partial<Subject>) {
    setSubjects(subjects.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  }

  function upsertTopic(subjectId: string, topic: Topic) {
    setSubjects(
      subjects.map((s) => {
        if (s.id !== subjectId) return s;
        const exists = s.topics.some((t) => t.id === topic.id);
        const topics = exists
          ? s.topics.map((t) => (t.id === topic.id ? topic : t))
          : [...s.topics, topic];
        return { ...s, topics };
      })
    );
  }

  function deleteTopic(subjectId: string, topicId: string) {
    setSubjects(
      subjects.map((s) =>
        s.id === subjectId ? { ...s, topics: s.topics.filter((t) => t.id !== topicId) } : s
      )
    );
  }

  return (
    <div className="container-page py-10">
      <PageHeader
        title="Performance Input"
        subtitle="Add your subjects, topics and marks. Percentages are calculated and validated automatically."
        icon={NotebookPen}
        actions={
          subjects.length === 0 ? (
            <button onClick={loadDemoData} className="btn-ghost px-4 py-2.5">
              <Lightbulb className="h-4 w-4" /> Load demo data
            </button>
          ) : (
            <button onClick={() => navigate("/app/analysis")} className="btn-primary px-4 py-2.5">
              <Sparkles className="h-4 w-4" /> Analyse performance
            </button>
          )
        }
      />

      {/* Add subject */}
      <div className="card-elevated p-6">
        <h3 className="text-base font-bold text-navy-900">Add a subject</h3>
        <p className="text-sm text-navy-500">e.g. Data Structures, Operating Systems, DBMS.</p>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <input
            className="input flex-1"
            placeholder="Subject name"
            value={newSubject}
            onChange={(e) => {
              setNewSubject(e.target.value);
              setSubjectError(null);
            }}
            onKeyDown={(e) => e.key === "Enter" && addSubject()}
          />
          <button onClick={addSubject} className="btn-primary px-5 py-3">
            <Plus className="h-4 w-4" /> Add subject
          </button>
        </div>
        {subjectError && (
          <p className="mt-2 flex items-center gap-1.5 text-xs font-medium text-rose-600">
            <AlertCircle className="h-3.5 w-3.5" /> {subjectError}
          </p>
        )}
      </div>

      {/* Subjects list */}
      <div className="mt-6 space-y-4">
        {subjects.length === 0 && (
          <EmptyState
            icon={NotebookPen}
            title="No subjects yet"
            description="Add your first subject above to start entering topic marks. You can also load demo data to explore the app."
            action={
              <button onClick={loadDemoData} className="btn-ghost px-5 py-2.5">
                <Lightbulb className="h-4 w-4" /> Load demo data
              </button>
            }
          />
        )}

        {subjects.map((subj) => {
          const perf = subjectPerformance(subj);
          const open = openSubjectId === subj.id;
          return (
            <div key={subj.id} className="card-elevated overflow-hidden">
              {/* Subject header */}
              <div className="flex items-center justify-between gap-4 p-5">
                <button
                  onClick={() => setOpenSubjectId(open ? null : subj.id)}
                  className="flex flex-1 items-center gap-3 text-left"
                >
                  <ChevronDown
                    className={`h-5 w-5 text-navy-400 transition-transform ${open ? "rotate-180" : ""}`}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-base font-bold text-navy-900">{subj.name}</p>
                    <p className="text-xs text-navy-500">
                      {subj.topics.length} topic{subj.topics.length !== 1 ? "s" : ""} ·{" "}
                      <span className={LEVEL_META[perf.level].text}>{LEVEL_META[perf.level].label}</span>
                    </p>
                  </div>
                </button>
                <div className="hidden items-center gap-3 sm:flex">
                  <div className="text-right">
                    <p className="text-xs font-medium text-navy-400">Average</p>
                    <p className="text-sm font-bold text-navy-900">{perf.percentage.toFixed(1)}%</p>
                  </div>
                  <div className="h-2 w-24 overflow-hidden rounded-full bg-navy-100">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${perf.percentage}%`,
                        background: LEVEL_META[perf.level].color,
                      }}
                    />
                  </div>
                  <button
                    onClick={() => deleteSubject(subj.id)}
                    className="grid h-9 w-9 place-items-center rounded-lg text-navy-400 hover:bg-rose-50 hover:text-rose-600"
                    aria-label="Delete subject"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Topics */}
              {open && (
                <div className="border-t border-navy-100 bg-navy-50/40 p-5">
                  <TopicForm
                    key={editingTopic?.topicId ?? "new"}
                    editing={editingTopic?.subjectId === subj.id ? editingTopic : null}
                    onSubmit={(topic) => {
                      if (editingTopic && editingTopic.topicId) {
                        upsertTopic(subj.id, { ...topic, id: editingTopic.topicId });
                      } else {
                        upsertTopic(subj.id, topic);
                      }
                      setEditingTopic(null);
                    }}
                    onCancel={() => setEditingTopic(null)}
                  />

                  {/* Topic list */}
                  <div className="mt-4 space-y-2">
                    {subj.topics.length === 0 && (
                      <p className="rounded-xl bg-white px-4 py-6 text-center text-sm text-navy-400 ring-1 ring-navy-100">
                        No topics yet. Add your first topic above.
                      </p>
                    )}
                    {subj.topics.map((t) => {
                      const pct = safePercentage(t.marksObtained, t.maxMarks);
                      const level = pct >= 75 ? "strong" : pct >= 50 ? "average" : "needs_improvement";
                      const meta = LEVEL_META[level];
                      return (
                        <div key={t.id} className="flex items-center gap-3 rounded-xl bg-white px-4 py-3 ring-1 ring-navy-100">
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-semibold text-navy-900">{t.name}</p>
                            <p className="text-xs text-navy-500">
                              {t.marksObtained} / {t.maxMarks} marks
                            </p>
                          </div>
                          <span className="hidden text-xs font-medium text-navy-500 sm:block">
                            {pct.toFixed(1)}%
                          </span>
                          <span className={`chip ${meta.bg} ${meta.text} ring-1 ${meta.ring}`}>{meta.short}</span>
                          <button
                            onClick={() => setEditingTopic({ subjectId: subj.id, topicId: t.id })}
                            className="grid h-8 w-8 place-items-center rounded-lg text-navy-400 hover:bg-navy-50 hover:text-navy-700"
                            aria-label="Edit topic"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => deleteTopic(subj.id, t.id)}
                            className="grid h-8 w-8 place-items-center rounded-lg text-navy-400 hover:bg-rose-50 hover:text-rose-600"
                            aria-label="Delete topic"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function TopicForm({
  editing,
  onSubmit,
  onCancel,
}: {
  editing: { topicId: string | null } | null;
  onSubmit: (topic: Topic) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState("");
  const [marks, setMarks] = useState("");
  const [max, setMax] = useState("100");
  const [error, setError] = useState<string | null>(null);

  function submit() {
    setError(null);
    if (!name.trim()) {
      setError("Enter a topic name.");
      return;
    }
    const m = Number(marks);
    const mx = Number(max);
    if (!Number.isFinite(m) || m < 0) {
      setError("Marks obtained must be 0 or more.");
      return;
    }
    if (!Number.isFinite(mx) || mx <= 0) {
      setError("Maximum marks must be greater than 0.");
      return;
    }
    if (m > mx) {
      setError("Marks obtained cannot exceed maximum marks.");
      return;
    }
    onSubmit({
      id: uid("topic"),
      name: name.trim(),
      marksObtained: m,
      maxMarks: mx,
      completed: false,
      createdAt: Date.now(),
    });
    setName("");
    setMarks("");
    setMax("100");
  }

  return (
    <div className="rounded-2xl bg-white p-4 ring-1 ring-navy-100">
      <div className="flex items-center gap-2 text-sm font-semibold text-navy-700">
        {editing?.topicId ? <Pencil className="h-4 w-4 text-royal-600" /> : <Plus className="h-4 w-4 text-royal-600" />}
        {editing?.topicId ? "Edit topic" : "Add topic"}
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_120px_120px_auto]">
        <div>
          <label className="label">Topic name</label>
          <input
            className="input"
            placeholder="e.g. Dynamic Programming"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
        </div>
        <div>
          <label className="label">Marks obtained</label>
          <input
            className="input"
            type="number"
            min={0}
            placeholder="0"
            value={marks}
            onChange={(e) => setMarks(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
        </div>
        <div>
          <label className="label">Maximum marks</label>
          <input
            className="input"
            type="number"
            min={1}
            placeholder="100"
            value={max}
            onChange={(e) => setMax(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
        </div>
        <div className="flex items-end gap-2">
          {editing?.topicId ? (
            <>
              <button onClick={submit} className="btn-primary px-4 py-3">
                <Save className="h-4 w-4" /> Save
              </button>
              <button onClick={onCancel} className="btn-ghost px-3 py-3">
                <X className="h-4 w-4" />
              </button>
            </>
          ) : (
            <button onClick={submit} className="btn-primary px-4 py-3">
              <Plus className="h-4 w-4" /> Add
            </button>
          )}
        </div>
      </div>
      {error && (
        <p className="mt-2 flex items-center gap-1.5 text-xs font-medium text-rose-600">
          <AlertCircle className="h-3.5 w-3.5" /> {error}
        </p>
      )}
    </div>
  );
}


