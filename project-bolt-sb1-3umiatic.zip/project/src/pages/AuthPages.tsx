import { useState } from "react";
import { AlertCircle, ArrowRight, Eye, EyeOff, Lock, Mail, Route, Sparkles, UserPlus } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { COURSE_OPTIONS } from "@/lib/demoData";

export function LoginPage() {
  const { navigate, login, loginDemo } = useApp();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!email.trim() || !password) {
      setError("Please enter your email and password.");
      return;
    }
    setBusy(true);
    const res = login(email, password);
    setBusy(false);
    if (!res.ok) {
      setError(res.error ?? "Login failed.");
      return;
    }
    navigate("/app");
  }

  function demo() {
    loginDemo();
    navigate("/app");
  }

  return (
    <AuthShell
      title="Welcome back"
      subtitle="Log in to continue your personalised learning journey."
      side="login"
    >
      <form onSubmit={submit} className="space-y-4">
        {error && (
          <div className="flex items-start gap-2 rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700 ring-1 ring-rose-200">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </div>
        )}
        <div>
          <label className="label" htmlFor="email">Email</label>
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-navy-400" />
            <input
              id="email"
              type="email"
              className="input pl-10"
              placeholder="you@university.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="password">Password</label>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-navy-400" />
            <input
              id="password"
              type={showPw ? "text" : "password"}
              className="input pl-10 pr-10"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
            <button
              type="button"
              onClick={() => setShowPw((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-600"
              aria-label={showPw ? "Hide password" : "Show password"}
            >
              {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <button type="submit" disabled={busy} className="btn-primary w-full py-3.5 text-base">
          {busy ? "Logging in…" : "Login"} <ArrowRight className="h-4 w-4" />
        </button>
      </form>

      <div className="my-5 flex items-center gap-3 text-xs font-medium text-navy-400">
        <div className="h-px flex-1 bg-navy-100" />
        or
        <div className="h-px flex-1 bg-navy-100" />
      </div>

      <button onClick={demo} className="btn-navy w-full py-3.5 text-base">
        <Sparkles className="h-4 w-4" /> Continue with demo account
      </button>
      <p className="mt-3 text-center text-xs text-navy-500">
        The demo account comes pre-filled with sample subjects, marks and progress.
      </p>

      <p className="mt-6 text-center text-sm text-navy-600">
        Don&apos;t have an account?{" "}
        <button onClick={() => navigate("/register")} className="font-semibold text-royal-700 hover:text-royal-800">
          Create one
        </button>
      </p>
    </AuthShell>
  );
}

export function RegisterPage() {
  const { navigate, register } = useApp();
  const [form, setForm] = useState({ name: "", email: "", password: "", course: COURSE_OPTIONS[0] });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showPw, setShowPw] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  function validate() {
    const e: Record<string, string> = {};
    if (form.name.trim().length < 2) e.name = "Enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Enter a valid email address.";
    if (form.password.length < 6) e.password = "Password must be at least 6 characters.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function submit(ev: React.FormEvent) {
    ev.preventDefault();
    setServerError(null);
    if (!validate()) return;
    const res = register(form);
    if (!res.ok) {
      setServerError(res.error ?? "Registration failed.");
      return;
    }
    navigate("/app");
  }

  return (
    <AuthShell
      title="Create your account"
      subtitle="Join Learning Path Recommender and get a study plan designed around you."
      side="register"
    >
      <form onSubmit={submit} className="space-y-4">
        {serverError && (
          <div className="flex items-start gap-2 rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700 ring-1 ring-rose-200">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {serverError}
          </div>
        )}
        <div>
          <label className="label" htmlFor="name">Student name</label>
          <input
            id="name"
            className="input"
            placeholder="Aarav Sharma"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          {errors.name && <p className="mt-1 text-xs font-medium text-rose-600">{errors.name}</p>}
        </div>
        <div>
          <label className="label" htmlFor="email">Email</label>
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-navy-400" />
            <input
              id="email"
              type="email"
              className="input pl-10"
              placeholder="you@university.edu"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>
          {errors.email && <p className="mt-1 text-xs font-medium text-rose-600">{errors.email}</p>}
        </div>
        <div>
          <label className="label" htmlFor="password">Password</label>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-navy-400" />
            <input
              id="password"
              type={showPw ? "text" : "password"}
              className="input pl-10 pr-10"
              placeholder="At least 6 characters"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
            <button
              type="button"
              onClick={() => setShowPw((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-600"
              aria-label={showPw ? "Hide password" : "Show password"}
            >
              {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {errors.password && <p className="mt-1 text-xs font-medium text-rose-600">{errors.password}</p>}
        </div>
        <div>
          <label className="label" htmlFor="course">Course / Department</label>
          <select
            id="course"
            className="input"
            value={form.course}
            onChange={(e) => setForm({ ...form, course: e.target.value })}
          >
            {COURSE_OPTIONS.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn-primary w-full py-3.5 text-base">
          <UserPlus className="h-4 w-4" /> Create account
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-navy-600">
        Already have an account?{" "}
        <button onClick={() => navigate("/login")} className="font-semibold text-royal-700 hover:text-royal-800">
          Login
        </button>
      </p>
    </AuthShell>
  );
}

function AuthShell({
  title,
  subtitle,
  side,
  children,
}: {
  title: string;
  subtitle: string;
  side: "login" | "register";
  children: React.ReactNode;
}) {
  return (
    <div className="relative min-h-[calc(100vh-4rem)] overflow-hidden bg-navy-50">
      <div className="absolute inset-0 bg-mesh" />
      <div className="container-page relative grid min-h-[calc(100vh-4rem)] items-center gap-10 py-12 lg:grid-cols-2">
        {/* Left brand panel */}
        <div className="hidden lg:block">
          <div className="relative overflow-hidden rounded-3xl bg-navy-gradient p-10 text-white shadow-card">
            <div className="absolute inset-0 grid-pattern opacity-30" />
            <div className="relative">
              <div className="flex items-center gap-2.5">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/15 ring-1 ring-white/20">
                  <Route className="h-5 w-5" />
                </span>
                <span className="text-base font-extrabold">Learning Path Recommender</span>
              </div>
              <h2 className="mt-10 text-3xl font-extrabold leading-tight">
                {side === "login"
                  ? "Welcome back. Your study plan is waiting."
                  : "Design a learning path around your marks."}
              </h2>
              <p className="mt-3 max-w-md text-navy-100">
                {side === "login"
                  ? "Log in to see your dashboard, recommendations and progress — all generated dynamically from your performance."
                  : "Create a free demo account, add your subjects and topics, and instantly get a personalised, prioritised learning path."}
              </p>
              <ul className="mt-8 space-y-3">
                {[
                  "Topic-wise performance classification",
                  "Priority-scored recommendations",
                  "Curated resources per topic",
                  "Progress tracking that updates live",
                ].map((t) => (
                  <li key={t} className="flex items-center gap-3 text-sm text-navy-100">
                    <span className="grid h-6 w-6 place-items-center rounded-md bg-white/15">
                      <Sparkles className="h-3.5 w-3.5 text-lavender-200" />
                    </span>
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Right form panel */}
        <div className="mx-auto w-full max-w-md">
          <div className="card-elevated p-8">
            <h1 className="text-2xl font-extrabold tracking-tight text-navy-900">{title}</h1>
            <p className="mt-1 text-sm text-navy-500">{subtitle}</p>
            <div className="mt-6">{children}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
