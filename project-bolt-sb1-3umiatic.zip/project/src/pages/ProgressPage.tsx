import { useMemo } from "react";
import {
  Award,
  CheckCircle2,
  Circle,
  Flame,
  Lightbulb,
  ListChecks,
  Medal,
  Route,
  Sparkles,
  Target,
  TrendingUp,
} from "lucide-react";
import { useApp } from "@/context/AppContext";
import { Donut, ProgressBar } from "@/components/charts";
import { EmptyState, PageHeader, StatCard } from "@/components/ui";
import { allTopicPerformances, learningProgress } from "@/lib/performance";
import { topRecommendations } from "@/lib/recommendations";

export function ProgressPage() {
  const { subjects, setSubjects, navigate, loadDemoData } = useApp();

  const topicPerfs = allTopicPerformances(subjects);
  const progress = learningProgress(subjects);
  const completed = topicPerfs.filter((t) => t.topic.completed);
  const pending = topicPerfs.filter((t) => !t.topic.completed);
  const total = topicPerfs.length;

  const recs = topRecommendations(subjects, 3);

  // Milestones
  const milestones = useMemo(() => {
    const pct = total ? (completed.length / total) * 100 : 0;
    return [
      { label: "First topic", threshold: 1, reached: completed.length >= 1, icon: Sparkles },
      { label: "25% complete", threshold: 25, reached: pct >= 25, icon: TrendingUp },
      { label: "Halfway there", threshold: 50, reached: pct >= 50, icon: Medal },
      { label: "75% complete", threshold: 75, reached: pct >= 75, icon: Award },
      { label: "All complete", threshold: 100, reached: pct >= 100, icon: Flame },
    ];
  }, [completed.length, total]);

  function toggle(subjectId: string, topicId: string, isCompleted: boolean) {
    setSubjects(
      subjects.map((s) =>
        s.id !== subjectId
          ? s
          : {
              ...s,
              topics: s.topics.map((t) =>
                t.id === topicId ? { ...t, completed: !isCompleted } : t
              ),
            }
      )
    );
  }

  const hasData = total > 0;

  return (
    <div className="container-page py-10">
      <PageHeader
        title="Progress Tracker"
        subtitle="Mark topics complete, track what's pending, and celebrate your learning milestones."
        icon={ListChecks}
        actions={
          !hasData ? (
            <button onClick={loadDemoData} className="btn-ghost px-4 py-2.5">
              <Lightbulb className="h-4 w-4" /> Load demo data
            </button>
          ) : null
        }
      />

      {!hasData ? (
        <EmptyState
          icon={ListChecks}
          title="No topics to track yet"
          description="Add your subjects and topic marks on the Performance Input page, then come back here to mark them complete and watch your progress climb."
          action={
            <div className="flex flex-wrap justify-center gap-2">
              <button onClick={() => navigate("/app/performance")} className="btn-primary px-5 py-2.5">
                Add performance
              </button>
              <button onClick={loadDemoData} className="btn-ghost px-5 py-2.5">
                <Lightbulb className="h-4 w-4" /> Load demo data
              </button>
            </div>
          }
        />
      ) : (
        <>
          {/* Overview stats */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard icon={Target} label="Overall progress" value={`${progress.toFixed(0)}%`} hint={`${completed.length} of ${total}`} accent="lavender" />
            <StatCard icon={CheckCircle2} label="Completed topics" value={completed.length} accent="emerald" />
            <StatCard icon={Circle} label="Pending topics" value={pending.length} accent="amber" />
            <StatCard icon={Award} label="Milestones reached" value={`${milestones.filter((m) => m.reached).length} / ${milestones.length}`} accent="royal" />
          </div>

          {/* Progress ring + milestones */}
          <div className="mt-6 grid gap-6 lg:grid-cols-3">
            <div className="card-elevated flex flex-col items-center justify-center p-6">
              <h3 className="mb-4 text-lg font-bold text-navy-900">Learning progress</h3>
              <Donut value={progress} size={160} stroke={16} color="#7c3aed" sublabel={`${completed.length} / ${total} done`} />
              <p className="mt-4 text-center text-sm text-navy-500">
                Keep marking topics complete to reach your next milestone.
              </p>
            </div>

            <div className="card-elevated p-6 lg:col-span-2">
              <div className="flex items-center gap-2">
                <Medal className="h-5 w-5 text-royal-600" />
                <h3 className="text-lg font-bold text-navy-900">Learning milestones</h3>
              </div>
              <p className="mt-1 text-sm text-navy-500">Celebrate as you hit each checkpoint.</p>
              <div className="mt-5 space-y-3">
                {milestones.map((m, i) => {
                  const pct = total ? (completed.length / total) * 100 : 0;
                  const progressToNext =
                    i === 0
                      ? m.reached
                        ? 100
                        : 0
                      : Math.max(0, Math.min(100, ((pct - milestones[i - 1].threshold) / (m.threshold - milestones[i - 1].threshold)) * 100));
                  return (
                    <div
                      key={m.label}
                      className={`flex items-center gap-3 rounded-2xl px-4 py-3 ring-1 transition ${
                        m.reached
                          ? "bg-emerald-50/60 ring-emerald-200"
                          : "bg-navy-50/40 ring-navy-100"
                      }`}
                    >
                      <div
                        className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${
                          m.reached
                            ? "bg-emerald-500 text-white"
                            : "bg-white text-navy-400 ring-1 ring-navy-200"
                        }`}
                      >
                        {m.reached ? <CheckCircle2 className="h-5 w-5" /> : <m.icon className="h-5 w-5" />}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <p className={`text-sm font-semibold ${m.reached ? "text-emerald-700" : "text-navy-700"}`}>
                            {m.label}
                          </p>
                          <span className="text-xs font-medium text-navy-400">
                            {m.reached ? "Reached" : `${m.threshold}% to go`}
                          </span>
                        </div>
                        <div className="mt-1.5">
                          <ProgressBar
                            value={m.reached ? 100 : progressToNext}
                            color={m.reached ? "#16a34a" : "#2563eb"}
                            height={6}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Completed + pending lists */}
          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <div className="card-elevated p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                  <h3 className="text-lg font-bold text-navy-900">Completed topics</h3>
                </div>
                <span className="chip bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200">
                  {completed.length}
                </span>
              </div>
              <div className="mt-4 space-y-2.5">
                {completed.length === 0 && (
                  <p className="rounded-xl bg-navy-50/50 px-4 py-6 text-center text-sm text-navy-400 ring-1 ring-navy-100">
                    No completed topics yet. Mark one done below to see it here.
                  </p>
                )}
                {completed.map((tp) => (
                  <div key={tp.topic.id} className="flex items-center gap-3 rounded-xl bg-emerald-50/50 px-4 py-3 ring-1 ring-emerald-100">
                    <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-navy-900">{tp.topic.name}</p>
                      <p className="text-xs text-navy-500">{tp.subjectName}</p>
                    </div>
                    <span className="chip bg-emerald-100 text-emerald-700">{tp.percentage.toFixed(0)}%</span>
                    <button
                      onClick={() => toggle(tp.subjectId, tp.topic.id, true)}
                      className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-navy-500 hover:bg-navy-50"
                    >
                      Undo
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="card-elevated p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Circle className="h-5 w-5 text-amber-600" />
                  <h3 className="text-lg font-bold text-navy-900">Pending topics</h3>
                </div>
                <span className="chip bg-amber-50 text-amber-700 ring-1 ring-amber-200">
                  {pending.length}
                </span>
              </div>
              <div className="mt-4 space-y-2.5">
                {pending.length === 0 && (
                  <p className="rounded-xl bg-navy-50/50 px-4 py-6 text-center text-sm text-navy-400 ring-1 ring-navy-100">
                    Everything is complete — outstanding work!
                  </p>
                )}
                {pending.map((tp) => (
                  <div key={tp.topic.id} className="flex items-center gap-3 rounded-xl bg-white px-4 py-3 ring-1 ring-navy-100">
                    <Circle className="h-5 w-5 shrink-0 text-navy-300" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-navy-900">{tp.topic.name}</p>
                      <p className="text-xs text-navy-500">{tp.subjectName}</p>
                    </div>
                    <span className="chip bg-navy-50 text-navy-600 ring-1 ring-navy-200">{tp.percentage.toFixed(0)}%</span>
                    <button
                      onClick={() => toggle(tp.subjectId, tp.topic.id, false)}
                      className="inline-flex items-center gap-1 rounded-lg bg-emerald-500 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-600"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" /> Done
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Up next */}
          {recs.length > 0 && (
            <div className="mt-6 card-elevated p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Route className="h-5 w-5 text-royal-600" />
                  <h3 className="text-lg font-bold text-navy-900">Up next</h3>
                </div>
                <button onClick={() => navigate("/app/path")} className="btn-soft px-3.5 py-2 text-xs">
                  Full path
                </button>
              </div>
              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                {recs.map((r, i) => (
                  <div key={r.topicPerformance.topic.id} className="rounded-2xl bg-navy-50/50 p-4 ring-1 ring-navy-100">
                    <p className="text-xs font-semibold text-royal-700">#{i + 1} priority</p>
                    <p className="mt-1 truncate text-sm font-bold text-navy-900">{r.topicPerformance.topic.name}</p>
                    <p className="text-xs text-navy-500">{r.topicPerformance.subjectName}</p>
                    <div className="mt-3">
                      <button
                        onClick={() => toggle(r.topicPerformance.subjectId, r.topicPerformance.topic.id, false)}
                        className="inline-flex items-center gap-1 rounded-lg bg-emerald-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-600"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" /> Mark done
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
