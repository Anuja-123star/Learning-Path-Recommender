import {
  ArrowRight,
  BarChart3,
  Lightbulb,
  Route,
  TrendingDown,
  TrendingUp,
  Trophy,
} from "lucide-react";
import { useApp } from "@/context/AppContext";
import { BarChart, ProgressBar, StackedBar } from "@/components/charts";
import { EmptyState, PageHeader, StatCard } from "@/components/ui";
import {
  allTopicPerformances,
  averageScore,
  LEVEL_META,
  subjectPerformance,
} from "@/lib/performance";
import { buildLearningPath } from "@/lib/recommendations";

const SUBJECT_COLORS = ["#2563eb", "#7c3aed", "#16a34a", "#d97706", "#dc2626", "#0891b2", "#db2777"];

export function AnalysisPage() {
  const { subjects, navigate, loadDemoData } = useApp();

  const topicPerfs = allTopicPerformances(subjects);
  const subjPerfs = subjects.map(subjectPerformance);
  const avg = averageScore(subjects);
  const recs = buildLearningPath(subjects);

  const counts = {
    strong: topicPerfs.filter((t) => t.level === "strong").length,
    average: topicPerfs.filter((t) => t.level === "average").length,
    needs_improvement: topicPerfs.filter((t) => t.level === "needs_improvement").length,
  };

  const strongest = [...topicPerfs].sort((a, b) => b.percentage - a.percentage)[0];
  const weakest = [...topicPerfs].sort((a, b) => a.percentage - b.percentage)[0];

  const hasData = topicPerfs.length > 0;

  return (
    <div className="container-page py-10">
      <PageHeader
        title="Performance Analysis"
        subtitle="Topic-wise and subject-wise breakdowns with strength and weakness analysis."
        icon={BarChart3}
        actions={
          hasData ? (
            <button onClick={() => navigate("/app/path")} className="btn-primary px-4 py-2.5">
              <Route className="h-4 w-4" /> View learning path
            </button>
          ) : (
            <button onClick={loadDemoData} className="btn-ghost px-4 py-2.5">
              <Lightbulb className="h-4 w-4" /> Load demo data
            </button>
          )
        }
      />

      {!hasData ? (
        <EmptyState
          icon={BarChart3}
          title="Nothing to analyse yet"
          description="Add your subjects and topic marks on the Performance Input page, and your analysis will appear here automatically."
          action={
            <div className="flex flex-wrap justify-center gap-2">
              <button onClick={() => navigate("/app/performance")} className="btn-primary px-5 py-2.5">
                Add performance
              </button>
              <button onClick={loadDemoData} className="btn-ghost px-5 py-2.5">
                <Lightbulb className="h-4 w-4" /> Load demo data
              </button>
            </div>
          }
        />
      ) : (
        <>
          {/* Summary stats */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard icon={TrendingUp} label="Average performance" value={`${avg.toFixed(1)}%`} accent={avg >= 75 ? "emerald" : avg >= 50 ? "amber" : "rose"} />
            <StatCard icon={Trophy} label="Strong topics" value={counts.strong} hint="75% or above" accent="emerald" />
            <StatCard icon={BarChart3} label="Average topics" value={counts.average} hint="50% – 74%" accent="amber" />
            <StatCard icon={TrendingDown} label="Needs improvement" value={counts.needs_improvement} hint="Below 50%" accent="rose" />
          </div>

          {/* Subject-wise chart */}
          <div className="mt-6 card-elevated p-6">
            <h3 className="text-lg font-bold text-navy-900">Subject-wise performance</h3>
            <p className="text-sm text-navy-500">Average percentage of each subject's topics, with level classification.</p>
            <div className="mt-5">
              <BarChart
                data={subjPerfs.map((p, i) => ({
                  label: p.subject.name,
                  value: Math.round(p.percentage * 10) / 10,
                  color: SUBJECT_COLORS[i % SUBJECT_COLORS.length],
                }))}
              />
            </div>
          </div>

          {/* Subject breakdown table */}
          <div className="mt-6 card-elevated overflow-hidden">
            <div className="border-b border-navy-100 p-6">
              <h3 className="text-lg font-bold text-navy-900">Subject breakdown</h3>
              <p className="text-sm text-navy-500">Topic distribution and average per subject.</p>
            </div>
            <div className="divide-y divide-navy-100">
              {subjPerfs.map((p, i) => {
                const meta = LEVEL_META[p.level];
                return (
                  <div key={p.subject.id} className="p-6">
                    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex items-center gap-3">
                        <span
                          className="h-10 w-1.5 rounded-full"
                          style={{ background: SUBJECT_COLORS[i % SUBJECT_COLORS.length] }}
                        />
                        <div>
                          <p className="text-base font-bold text-navy-900">{p.subject.name}</p>
                          <p className="text-xs text-navy-500">{p.topicCount} topics</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className={`chip ${meta.bg} ${meta.text} ring-1 ${meta.ring}`}>{meta.label}</span>
                        <div className="w-28">
                          <ProgressBar value={p.percentage} color={meta.color} height={8} />
                        </div>
                        <span className="w-14 text-right text-sm font-bold text-navy-900">{p.percentage.toFixed(0)}%</span>
                      </div>
                    </div>
                    <div className="mt-3 grid gap-3 sm:grid-cols-3">
                      <MiniStat label="Strong" value={p.strongCount} color="#16a34a" />
                      <MiniStat label="Average" value={p.averageCount} color="#d97706" />
                      <MiniStat label="Needs work" value={p.weakCount} color="#dc2626" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Topic-wise performance */}
          <div className="mt-6 grid gap-6 lg:grid-cols-3">
            <div className="card-elevated p-6 lg:col-span-2">
              <h3 className="text-lg font-bold text-navy-900">Topic-wise performance</h3>
              <p className="text-sm text-navy-500">All topics across every subject, sorted by percentage.</p>
              <div className="mt-4 max-h-[28rem] space-y-2 overflow-y-auto scrollbar-thin pr-1">
                {[...topicPerfs]
                  .sort((a, b) => b.percentage - a.percentage)
                  .map((tp) => {
                    const meta = LEVEL_META[tp.level];
                    return (
                      <div key={tp.topic.id} className="rounded-xl bg-navy-50/50 px-4 py-3 ring-1 ring-navy-100">
                        <div className="flex items-center justify-between gap-2">
                          <p className="truncate text-sm font-semibold text-navy-900">{tp.topic.name}</p>
                          <span className={`chip ${meta.bg} ${meta.text} ring-1 ${meta.ring}`}>{tp.percentage.toFixed(0)}%</span>
                        </div>
                        <p className="mt-0.5 text-xs text-navy-500">{tp.subjectName}</p>
                        <div className="mt-2">
                          <ProgressBar value={tp.percentage} color={meta.color} height={6} />
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>

            {/* Strength & weakness highlight */}
            <div className="space-y-6">
              {strongest && (
                <div className="card-elevated p-6">
                  <div className="flex items-center gap-2 text-emerald-700">
                    <Trophy className="h-5 w-5" />
                    <h3 className="text-base font-bold text-navy-900">Strongest topic</h3>
                  </div>
                  <p className="mt-2 text-sm font-semibold text-navy-900">{strongest.topic.name}</p>
                  <p className="text-xs text-navy-500">{strongest.subjectName}</p>
                  <p className="mt-3 text-3xl font-extrabold text-emerald-600">{strongest.percentage.toFixed(0)}%</p>
                </div>
              )}
              {weakest && (
                <div className="card-elevated p-6">
                  <div className="flex items-center gap-2 text-rose-700">
                    <TrendingDown className="h-5 w-5" />
                    <h3 className="text-base font-bold text-navy-900">Weakest topic</h3>
                  </div>
                  <p className="mt-2 text-sm font-semibold text-navy-900">{weakest.topic.name}</p>
                  <p className="text-xs text-navy-500">{weakest.subjectName}</p>
                  <p className="mt-3 text-3xl font-extrabold text-rose-600">{weakest.percentage.toFixed(0)}%</p>
                </div>
              )}
              <div className="card-elevated p-6">
                <h3 className="text-base font-bold text-navy-900">Performance mix</h3>
                <p className="text-sm text-navy-500">Distribution of all topics.</p>
                <div className="mt-4">
                  <StackedBar
                    segments={[
                      { value: counts.strong, color: "#16a34a", label: "Strong" },
                      { value: counts.average, color: "#d97706", label: "Average" },
                      { value: counts.needs_improvement, color: "#dc2626", label: "Needs work" },
                    ]}
                  />
                  <div className="mt-3 space-y-1.5 text-xs font-medium text-navy-500">
                    <div className="flex justify-between"><span><span className="text-emerald-600">●</span> Strong</span><span>{counts.strong}</span></div>
                    <div className="flex justify-between"><span><span className="text-amber-600">●</span> Average</span><span>{counts.average}</span></div>
                    <div className="flex justify-between"><span><span className="text-rose-600">●</span> Needs work</span><span>{counts.needs_improvement}</span></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Insight strip */}
          <div className="mt-6 card-elevated p-6">
            <div className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-royal-600" />
              <h3 className="text-lg font-bold text-navy-900">Insights</h3>
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <Insight
                ok={counts.strong > 0}
                text={counts.strong > 0 ? `${counts.strong} topic${counts.strong !== 1 ? "s" : ""} are strong — keep them sharp with advanced exercises.` : "No strong topics yet. Aim for 75%+ in a few topics."}
              />
              <Insight
                ok={counts.needs_improvement === 0}
                text={counts.needs_improvement > 0 ? `${counts.needs_improvement} topic${counts.needs_improvement !== 1 ? "s need" : " needs"} urgent attention — they're below 50%.` : "Great — no topics below 50%."}
              />
              <Insight
                ok={avg >= 60}
                text={avg >= 60 ? `Overall average is ${avg.toFixed(0)}% — a solid foundation to build on.` : `Overall average is ${avg.toFixed(0)}%. Focus on weak topics to lift it.`}
              />
              <Insight
                ok={recs.length > 0}
                text={recs.length > 0 ? "Your learning path is ready — the top recommendation is below." : "All topics complete. Consider adding more topics to keep improving."}
                action={
                  recs.length > 0 ? (
                    <button onClick={() => navigate("/app/path")} className="text-xs font-semibold text-royal-700 hover:text-royal-800">
                      Open path <ArrowRight className="inline h-3 w-3" />
                    </button>
                  ) : undefined
                }
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function MiniStat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center justify-between rounded-lg bg-white px-3 py-2 ring-1 ring-navy-100">
      <span className="flex items-center gap-1.5 text-xs font-medium text-navy-500">
        <span className="h-2 w-2 rounded-full" style={{ background: color }} /> {label}
      </span>
      <span className="text-sm font-bold text-navy-900">{value}</span>
    </div>
  );
}

function Insight({ ok, text, action }: { ok: boolean; text: string; action?: React.ReactNode }) {
  return (
    <div className={`flex items-start gap-2 rounded-xl px-4 py-3 text-sm ring-1 ${ok ? "bg-emerald-50/60 text-navy-700 ring-emerald-100" : "bg-amber-50/60 text-navy-700 ring-amber-100"}`}>
      <span className={`mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full ${ok ? "bg-emerald-500" : "bg-amber-500"}`}>
        <span className="text-[10px] font-bold text-white">{ok ? "✓" : "!"}</span>
      </span>
      <div className="flex-1">{text}{action && <div className="mt-1">{action}</div>}</div>
    </div>
  );
}
