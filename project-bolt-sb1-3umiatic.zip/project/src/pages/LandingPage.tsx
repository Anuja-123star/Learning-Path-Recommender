import {
  ArrowRight,
  BarChart3,
  BookOpen,
  Brain,
  CheckCircle2,
  ClipboardList,
  Compass,
  GraduationCap,
  LineChart,
  ListChecks,
  PenLine,
  Route,
  Sparkles,
  Target,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";
import { useApp } from "@/context/AppContext";

const HERO_IMG =
  "https://images.pexels.com/photos/8199653/pexels-photo-8199653.jpeg?auto=compress&cs=tinysrgb&h=900&w=700";

export function LandingPage() {
  const { navigate } = useApp();

  return (
    <div className="bg-white">
      {/* ===== HERO ===== */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-mesh" />
        <div className="absolute -left-32 top-10 h-72 w-72 rounded-full bg-royal-200/40 blur-3xl" />
        <div className="absolute -right-24 bottom-0 h-80 w-80 rounded-full bg-lavender-200/40 blur-3xl" />

        <div className="container-page relative grid items-center gap-12 py-16 lg:grid-cols-2 lg:py-24">
          <div className="animate-fade-up">
            <span className="section-eyebrow">
              <Sparkles className="h-3.5 w-3.5" /> Personalised academic guidance
            </span>
            <h1 className="mt-5 text-balance text-4xl font-extrabold leading-[1.08] tracking-tight text-navy-950 sm:text-5xl lg:text-6xl">
              Your Learning Journey, <br className="hidden sm:block" />
              <span className="bg-royal-gradient bg-clip-text text-transparent">
                Designed Around You.
              </span>
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-navy-600">
              Discover your strengths, improve your weaknesses and follow a
              personalised learning path designed around your academic
              performance.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <button onClick={() => navigate("/register")} className="btn-primary px-6 py-3.5 text-base">
                Start Learning <ArrowRight className="h-4 w-4" />
              </button>
              <button onClick={() => navigate("/#features")} className="btn-ghost px-6 py-3.5 text-base">
                Explore Features
              </button>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-4">
              {[
                { icon: Users, label: "Built for CS students" },
                { icon: Zap, label: "Instant recommendations" },
                { icon: Target, label: "Rule-based, no AI needed" },
              ].map((f) => (
                <div key={f.label} className="flex items-center gap-2 text-sm font-medium text-navy-600">
                  <span className="grid h-8 w-8 place-items-center rounded-lg bg-navy-50 text-royal-600 ring-1 ring-navy-100">
                    <f.icon className="h-4 w-4" />
                  </span>
                  {f.label}
                </div>
              ))}
            </div>
          </div>

          <div className="relative animate-fade-in">
            <div className="relative mx-auto max-w-md">
              {/* Hero image card */}
              <div className="relative overflow-hidden rounded-3xl bg-navy-gradient p-3 shadow-card ring-1 ring-navy-100">
                <img
                  src={HERO_IMG}
                  alt="Student studying with a laptop and books"
                  className="h-[420px] w-full rounded-2xl object-cover"
                  loading="eager"
                />
                <div className="absolute inset-0 rounded-3xl ring-1 ring-inset ring-white/10" />
              </div>

              {/* Floating stat: subject performance */}
              <div className="absolute -left-6 top-10 hidden animate-float rounded-2xl bg-white p-3.5 shadow-card ring-1 ring-navy-100 sm:block">
                <div className="flex items-center gap-2">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-royal-50 text-royal-600">
                    <BarChart3 className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-navy-500">Avg. performance</p>
                    <p className="text-sm font-bold text-navy-900">68.4%</p>
                  </div>
                </div>
              </div>

              {/* Floating stat: recommended topic */}
              <div className="absolute -right-5 bottom-12 hidden animate-float rounded-2xl bg-white p-3.5 shadow-card ring-1 ring-navy-100 sm:block" style={{ animationDelay: "1.5s" }}>
                <div className="flex items-center gap-2.5">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-lavender-50 text-lavender-600">
                    <Route className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-navy-500">Next focus</p>
                    <p className="text-sm font-bold text-navy-900">Dynamic Programming</p>
                  </div>
                </div>
              </div>

              {/* Floating mini progress */}
              <div className="absolute -bottom-5 left-1/2 hidden -translate-x-1/2 animate-float rounded-2xl bg-white px-4 py-2.5 shadow-card ring-1 ring-navy-100 sm:flex" style={{ animationDelay: "0.8s" }}>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                  <span className="text-xs font-semibold text-navy-700">5 of 21 topics completed</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== A. WHY PERSONALISED LEARNING ===== */}
      <section className="relative bg-white py-20">
        <div className="container-page">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <span className="section-eyebrow"><Brain className="h-3.5 w-3.5" /> Why personalisation</span>
              <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-navy-900 sm:text-4xl">
                Why Personalised Learning?
              </h2>
              <p className="mt-4 text-base leading-relaxed text-navy-600">
                Every student learns differently. Two people in the same
                classroom can walk out with completely different grasps of the
                same topic — one breezes through trees but stumbles on graphs,
                the other is the exact opposite.
              </p>
              <p className="mt-4 text-base leading-relaxed text-navy-600">
                A one-size-fits-all syllabus wastes time on what you already know
                and skips what you don't. Learning Path Recommender reads your
                academic performance topic-by-topic and builds a study plan that
                spends your effort where it actually matters.
              </p>
              <ul className="mt-6 space-y-3">
                {[
                  "Focus on weak topics first, using a transparent priority score.",
                  "Reinforce strong topics with advanced exercises instead of re-learning them.",
                  "Track real progress as you complete topics — not just marks.",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-3 text-sm font-medium text-navy-700">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-500" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {[
                { icon: Target, title: "Targeted practice", text: "Drill the exact topics dragging your average down." },
                { icon: TrendingUp, title: "Faster improvement", text: "Spend study hours where the score lifts the most." },
                { icon: BookOpen, title: "Curated resources", text: "Tutorials, notes and practice matched to each topic." },
                { icon: ListChecks, title: "Visible progress", text: "Watch the needle move as you complete topics." },
              ].map((c) => (
                <div key={c.title} className="card-elevated p-5 transition-transform duration-300 hover:-translate-y-1">
                  <div className="mb-3 inline-flex rounded-xl bg-navy-50 p-2.5 text-royal-600 ring-1 ring-navy-100">
                    <c.icon className="h-5 w-5" />
                  </div>
                  <p className="text-sm font-bold text-navy-900">{c.title}</p>
                  <p className="mt-1 text-sm text-navy-500">{c.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ===== B. HOW IT WORKS ===== */}
      <section id="how" className="relative overflow-hidden bg-navy-gradient py-20 text-white">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="container-page relative">
          <div className="mx-auto max-w-2xl text-center">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-lavender-200 ring-1 ring-white/15">
              <Compass className="h-3.5 w-3.5" /> How It Works
            </span>
            <h2 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">
              Four steps to a smarter study plan
            </h2>
            <p className="mt-3 text-base text-navy-100">
              From raw marks to a personalised path in minutes — no external AI,
              no paid APIs. Everything runs in your browser.
            </p>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-4">
            {[
              { n: "01", icon: ClipboardList, title: "Enter performance", text: "Add your subjects, the topics under each, and the marks you obtained. Percentages calculate automatically." },
              { n: "02", icon: BarChart3, title: "Analyse topics", text: "We classify each topic as Strong, Average or Needs Improvement and visualise subject-wise trends." },
              { n: "03", icon: Route, title: "Generate your path", text: "A weighted priority score ranks topics so the weakest, most impactful ones come first." },
              { n: "04", icon: LineChart, title: "Track progress", text: "Mark topics complete, watch your overall progress climb, and hit learning milestones." },
            ].map((s, i) => (
              <div key={s.n} className="group relative rounded-2xl bg-white/5 p-6 ring-1 ring-white/10 backdrop-blur-sm transition-colors hover:bg-white/10">
                <div className="flex items-center justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/10 ring-1 ring-white/15">
                    <s.icon className="h-6 w-6 text-lavender-200" />
                  </span>
                  <span className="text-3xl font-extrabold text-white/15">{s.n}</span>
                </div>
                <h3 className="mt-5 text-lg font-bold">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-navy-100">{s.text}</p>
                {i < 3 && (
                  <div className="absolute -right-3 top-1/2 hidden -translate-y-1/2 text-white/30 md:block">
                    <ArrowRight className="h-5 w-5" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== C. KEY FEATURES ===== */}
      <section id="features" className="bg-white py-20">
        <div className="container-page">
          <div className="mx-auto max-w-2xl text-center">
            <span className="section-eyebrow"><Sparkles className="h-3.5 w-3.5" /> Features</span>
            <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-navy-900 sm:text-4xl">
              Everything a student needs to improve
            </h2>
            <p className="mt-3 text-base text-navy-500">
              Four core capabilities that turn your marks into a clear, actionable plan.
            </p>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: BarChart3, title: "Performance Analysis", text: "Topic- and subject-wise breakdowns with classification and visual charts.", iconWrap: "bg-royal-50 ring-royal-100", iconColor: "text-royal-600" },
              { icon: Brain, title: "Smart Recommendations", text: "A transparent priority score ranks what to study next, dynamically.", iconWrap: "bg-lavender-50 ring-lavender-100", iconColor: "text-lavender-600" },
              { icon: BookOpen, title: "Learning Resources", text: "Tutorials, notes, practice questions and activities per topic.", iconWrap: "bg-emerald-50 ring-emerald-100", iconColor: "text-emerald-600" },
              { icon: LineChart, title: "Progress Tracking", text: "Mark topics done, track completion and celebrate milestones.", iconWrap: "bg-amber-50 ring-amber-100", iconColor: "text-amber-600" },
            ].map((f) => (
              <div key={f.title} className="card-elevated group p-6 transition-transform duration-300 hover:-translate-y-1.5">
                <div className={`mb-4 inline-flex rounded-2xl p-3 ring-1 ${f.iconWrap}`}>
                  <f.icon className={`h-6 w-6 ${f.iconColor}`} />
                </div>
                <h3 className="text-lg font-bold text-navy-900">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-navy-500">{f.text}</p>
              </div>
            ))}
          </div>

          {/* Feature detail strip */}
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            <div className="card-elevated p-6">
              <div className="flex items-center gap-2 text-royal-700">
                <PenLine className="h-5 w-5" />
                <h3 className="text-base font-bold text-navy-900">Validated inputs</h3>
              </div>
              <p className="mt-2 text-sm text-navy-500">
                Marks are validated as you type — no negative scores, no totals
                above the maximum. Percentages are computed live.
              </p>
            </div>
            <div className="card-elevated p-6">
              <div className="flex items-center gap-2 text-lavender-700">
                <Route className="h-5 w-5" />
                <h3 className="text-base font-bold text-navy-900">Dynamic path</h3>
              </div>
              <p className="mt-2 text-sm text-navy-500">
                The moment you change a mark, the priority score and the
                recommended order update instantly — no static outputs.
              </p>
            </div>
            <div className="card-elevated p-6">
              <div className="flex items-center gap-2 text-emerald-700">
                <ListChecks className="h-5 w-5" />
                <h3 className="text-base font-bold text-navy-900">Persists on refresh</h3>
              </div>
              <p className="mt-2 text-sm text-navy-500">
                Your subjects, marks and progress are saved in your browser, so
                everything is still here when you come back.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ===== D. FINAL CTA ===== */}
      <section id="about" className="bg-navy-50 py-20">
        <div className="container-page">
          <div className="relative overflow-hidden rounded-3xl bg-navy-gradient p-10 text-white shadow-card sm:p-16">
            <div className="absolute inset-0 grid-pattern opacity-30" />
            <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-royal-400/20 blur-3xl" />
            <div className="absolute -bottom-24 -left-16 h-72 w-72 rounded-full bg-lavender-400/20 blur-3xl" />
            <div className="relative mx-auto max-w-2xl text-center">
              <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-lavender-200 ring-1 ring-white/15">
                <GraduationCap className="h-3.5 w-3.5" /> Start now
              </span>
              <h2 className="mt-4 text-3xl font-extrabold tracking-tight sm:text-4xl">
                Build a learning path around your marks today
              </h2>
              <p className="mt-4 text-base text-navy-100">
                Create a free demo account, or jump straight in with a
                pre-filled demo student to see the full experience in seconds.
              </p>
              <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                <button onClick={() => navigate("/register")} className="btn bg-white text-navy-900 hover:bg-navy-50 px-6 py-3.5 text-base">
                  Create your account <ArrowRight className="h-4 w-4" />
                </button>
                <button onClick={() => navigate("/login")} className="btn bg-white/10 text-white ring-1 ring-white/20 hover:bg-white/15 px-6 py-3.5 text-base">
                  Try demo account
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
