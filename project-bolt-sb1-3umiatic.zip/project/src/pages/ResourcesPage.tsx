import { useMemo, useState } from "react";
import {
  BookOpen,
  Clock,
  ExternalLink,
  FileText,
  Lightbulb,
  Library,
  PencilRuler,
  PlayCircle,
  Search,
  Sparkles,
} from "lucide-react";
import { useApp } from "@/context/AppContext";
import { EmptyState, PageHeader } from "@/components/ui";
import { resourceTypeMeta, resourcesForSubjects } from "@/lib/resources";
import type { Resource } from "@/lib/types";

const TYPE_ICON = {
  tutorial: PlayCircle,
  notes: FileText,
  practice: PencilRuler,
  activity: Sparkles,
};

export function ResourcesPage() {
  const { subjects, navigate, loadDemoData } = useApp();
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<Resource["type"] | "all">("all");
  const [subjectFilter, setSubjectFilter] = useState<string>("all");

  const { byTopic, all } = useMemo(() => resourcesForSubjects(subjects), [subjects]);

  const filtered = all.filter((r) => {
    if (typeFilter !== "all" && r.type !== typeFilter) return false;
    if (subjectFilter !== "all" && r.subject !== subjectFilter) return false;
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      return (
        r.title.toLowerCase().includes(q) ||
        r.topic.toLowerCase().includes(q) ||
        r.subject.toLowerCase().includes(q) ||
        r.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const subjectNames = subjects.map((s) => s.name);
  const hasData = subjects.length > 0;

  // Group filtered resources by subject -> topic
  const grouped: Record<string, Record<string, Resource[]>> = {};
  filtered.forEach((r) => {
    (grouped[r.subject] ??= {});
    (grouped[r.subject][r.topic] ??= []).push(r);
  });

  return (
    <div className="container-page py-10">
      <PageHeader
        title="Learning Resources"
        subtitle="Tutorials, revision notes, practice questions and activities — organised by subject and topic."
        icon={Library}
        actions={
          !hasData ? (
            <button onClick={loadDemoData} className="btn-ghost px-4 py-2.5">
              <Lightbulb className="h-4 w-4" /> Load demo data
            </button>
          ) : null
        }
      />

      {!hasData ? (
        <EmptyState
          icon={Library}
          title="No subjects to match resources yet"
          description="Add your subjects on the Performance Input page, or load the demo data, and matching resources will appear here automatically."
          action={
            <div className="flex flex-wrap justify-center gap-2">
              <button onClick={() => navigate("/app/performance")} className="btn-primary px-5 py-2.5">
                Add subjects
              </button>
              <button onClick={loadDemoData} className="btn-ghost px-5 py-2.5">
                <Lightbulb className="h-4 w-4" /> Load demo data
              </button>
            </div>
          }
        />
      ) : (
        <>
          {/* Toolbar */}
          <div className="card-elevated p-5">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-navy-400" />
                <input
                  className="input pl-10"
                  placeholder="Search resources by name, topic or subject…"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </div>
              <select
                className="input lg:w-52"
                value={subjectFilter}
                onChange={(e) => setSubjectFilter(e.target.value)}
              >
                <option value="all">All subjects</option>
                {subjectNames.map((n) => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
              <div className="flex flex-wrap gap-1.5">
                {([
                  ["all", "All"],
                  ["tutorial", "Tutorials"],
                  ["notes", "Notes"],
                  ["practice", "Practice"],
                  ["activity", "Activities"],
                ] as [Resource["type"] | "all", string][]).map(([t, label]) => (
                  <button
                    key={t}
                    onClick={() => setTypeFilter(t)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                      typeFilter === t
                        ? "bg-navy-gradient text-white"
                        : "bg-white text-navy-600 ring-1 ring-navy-200 hover:bg-navy-50"
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
            <p className="mt-3 text-xs text-navy-400">
              {filtered.length} resource{filtered.length !== 1 ? "s" : ""} matching your filters.
            </p>
          </div>

          {/* Resources grouped */}
          {filtered.length === 0 ? (
            <div className="mt-6">
              <EmptyState
                icon={BookOpen}
                title="No matching resources"
                description="Try a different search term or clear your filters."
              />
            </div>
          ) : (
            <div className="mt-6 space-y-6">
              {Object.entries(grouped).map(([subject, topics]) => (
                <div key={subject} className="card-elevated overflow-hidden">
                  <div className="flex items-center gap-2 border-b border-navy-100 bg-navy-50/50 px-5 py-3.5">
                    <BookOpen className="h-4.5 w-4.5 text-royal-600" />
                    <h3 className="text-base font-bold text-navy-900">{subject}</h3>
                  </div>
                  <div className="divide-y divide-navy-100">
                    {Object.entries(topics).map(([topic, items]) => (
                      <div key={topic} className="p-5">
                        <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-navy-400">
                          {topic}
                        </p>
                        <div className="grid gap-3 sm:grid-cols-2">
                          {items.map((r) => (
                            <ResourceCard key={r.id} resource={r} />
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ResourceCard({ resource }: { resource: Resource }) {
  const meta = resourceTypeMeta(resource.type);
  const Icon = TYPE_ICON[resource.type];
  return (
    <a
      href={resource.url}
      target="_blank"
      rel="noopener noreferrer"
      className="group flex flex-col rounded-2xl bg-white p-4 ring-1 ring-navy-100 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-card"
    >
      <div className="flex items-start justify-between gap-3">
        <div className={`inline-flex rounded-xl p-2.5 ring-1 ${meta.bg} ${meta.ring}`}>
          <Icon className={`h-5 w-5 ${meta.color}`} />
        </div>
        <span className={`chip ${meta.bg} ${meta.color} ring-1 ${meta.ring}`}>{meta.label}</span>
      </div>
      <h4 className="mt-3 text-sm font-bold text-navy-900 group-hover:text-royal-700">
        {resource.title}
      </h4>
      <p className="mt-1 flex-1 text-xs leading-relaxed text-navy-500">{resource.description}</p>
      <div className="mt-3 flex items-center justify-between text-xs text-navy-400">
        <span className="flex items-center gap-1">
          <Clock className="h-3.5 w-3.5" /> {resource.duration}
        </span>
        <span className="flex items-center gap-1 font-semibold text-royal-600">
          Open <ExternalLink className="h-3.5 w-3.5" />
        </span>
      </div>
    </a>
  );
}
