import {
  ArrowRight,
  BookOpenCheck,
  ClipboardList,
  Flame,
  Lightbulb,
  ListChecks,
  Plus,
  Route,
  Sparkles,
  Target,
  TrendingUp,
  Trophy,
} from "lucide-react";
import { useApp } from "@/context/AppContext";
import { BarChart, Donut, ProgressBar, RadarChart, StackedBar } from "@/components/charts";
import { EmptyState, PageHeader, StatCard } from "@/components/ui";
import {
  allTopicPerformances,
  averageScore,
  LEVEL_META,
  learningProgress,
  subjectPerformance,
} from "@/lib/performance";
import { topRecommendations } from "@/lib/recommendations";

const SUBJECT_COLORS = ["#2563eb", "#7c3aed", "#16a34a", "#d97706", "#dc2626", "#0891b2", "#db2777"];

export function DashboardPage() {
  const { student, subjects, navigate, loadDemoData } = useApp();

  const totalSubjects = subjects.length;
  const totalTopics = subjects.reduce((n, s) => n + (s.topics?.length ?? 0), 0);
  const avg = averageScore(subjects);
  const progress = learningProgress(subjects);
  const completedTopics = subjects.reduce(
    (n, s) => n + (s.topics?.filter((t) => t.completed).length ?? 0),
    0
  );

  const topicPerfs = allTopicPerformances(subjects);
  const strongTopics = topicPerfs.filter((t) => t.level === "strong");
  const weakTopics = topicPerfs.filter((t) => t.level === "needs_improvement");

  const subjPerfs = subjects.map(subjectPerformance);
  const recs = topRecommendations(subjects, 5);

  const levelCounts = {
    strong: topicPerfs.filter((t) => t.level === "strong").length,
    average: topicPerfs.filter((t) => t.level === "average").length,
    needs_improvement: topicPerfs.filter((t) => t.level === "needs_improvement").length,
  };

  const hasData = totalTopics > 0;

  return (
    <div className="container-page py-10">
      {/* Welcome banner */}
      <div className="relative overflow-hidden rounded-3xl bg-navy-gradient p-8 text-white shadow-card">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-royal-400/20 blur-3xl" />
        <div className="relative flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-center">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-lavender-200 ring-1 ring-white/15">
              <Sparkles className="h-3.5 w-3.5" /> Dashboard
            </span>
            <h1 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">
              Welcome back, {student?.name.split(" ")[0]}.
            </h1>
            <p className="mt-2 max-w-xl text-navy-100">
              {hasData
                ? "Here's a snapshot of your academic performance and what to focus on next."
                : "Add your subjects and topic marks to unlock your personalised learning path."}
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <button onClick={() => navigate("/app/performance")} className="btn bg-white text-navy-900 hover:bg-navy-50 px-5 py-2.5">
                <Plus className="h-4 w-4" /> Add performance
              </button>
              <button onClick={() => navigate("/app/path")} className="btn bg-white/10 text-white ring-1 ring-white/20 hover:bg-white/15 px-5 py-2.5">
                <Route className="h-4 w-4" /> View learning path
              </button>
              {!hasData && (
                <button onClick={loadDemoData} className="btn bg-white/10 text-white ring-1 ring-white/20 hover:bg-white/15 px-5 py-2.5">
                  <Lightbulb className="h-4 w-4" /> Load demo data
                </button>
              )}
            </div>
          </div>
          {hasData && (
            <div className="shrink-0">
              <Donut value={progress} size={140} stroke={14} color="#c4b5fd" sublabel="Learning progress" />
            </div>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={BookOpenCheck} label="Total subjects" value={totalSubjects} hint="Subjects added" accent="royal" />
        <StatCard icon={ListChecks} label="Total topics" value={totalTopics} hint={`${completedTopics} completed`} accent="navy" />
        <StatCard
          icon={TrendingUp}
          label="Average performance"
          value={`${avg.toFixed(1)}%`}
          hint={LEVEL_META[avg >= 75 ? "strong" : avg >= 50 ? "average" : "needs_improvement"].label}
          accent={avg >= 75 ? "emerald" : avg >= 50 ? "amber" : "rose"}
        />
        <StatCard
          icon={Target}
          label="Learning progress"
          value={`${progress.toFixed(0)}%`}
          hint={`${completedTopics} / ${totalTopics} topics done`}
          accent="lavender"
        />
      </div>

      {!hasData ? (
        <div className="mt-6">
          <EmptyState
            icon={ClipboardList}
            title="No performance data yet"
            description="Add your subjects and the marks you obtained in each topic. We'll analyse them and build your personalised learning path instantly."
            action={
              <div className="flex flex-wrap justify-center gap-2">
                <button onClick={() => navigate("/app/performance")} className="btn-primary px-5 py-2.5">
                  <Plus className="h-4 w-4" /> Add your first subject
                </button>
                <button onClick={loadDemoData} className="btn-ghost px-5 py-2.5">
                  <Lightbulb className="h-4 w-4" /> Load demo data
                </button>
              </div>
            }
          />
        </div>
      ) : (
        <>
          {/* Charts row */}
          <div className="mt-6 grid gap-6 lg:grid-cols-3">
            {/* Subject-wise bar chart */}
            <div className="card-elevated p-6 lg:col-span-2">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-navy-900">Subject-wise performance</h3>
                  <p className="text-sm text-navy-500">Average percentage across each subject's topics.</p>
                </div>
                <button onClick={() => navigate("/app/analysis")} className="btn-soft px-3.5 py-2 text-xs">
                  Detailed analysis <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
              <BarChart
                data={subjPerfs.map((p, i) => ({
                  label: p.subject.name,
                  value: Math.round(p.percentage * 10) / 10,
                  color: SUBJECT_COLORS[i % SUBJECT_COLORS.length],
                }))}
              />
            </div>

            {/* Topic distribution donut / radar */}
            <div className="card-elevated p-6">
              <h3 className="text-lg font-bold text-navy-900">Topic distribution</h3>
              <p className="text-sm text-navy-500">By performance level.</p>
              <div className="mt-4 flex flex-col items-center gap-4">
                <Donut
                  value={totalTopics ? (levelCounts.strong / totalTopics) * 100 : 0}
                  size={130}
                  stroke={14}
                  color="#16a34a"
                  label={`${levelCounts.strong}`}
                  sublabel="Strong topics"
                />
                <div className="w-full space-y-2.5">
                  <DistRow color="#16a34a" label="Strong" value={levelCounts.strong} total={totalTopics} />
                  <DistRow color="#d97706" label="Average" value={levelCounts.average} total={totalTopics} />
                  <DistRow color="#dc2626" label="Needs work" value={levelCounts.needs_improvement} total={totalTopics} />
                </div>
              </div>
            </div>
          </div>

          {/* Strength radar + strong/weak lists */}
          <div className="mt-6 grid gap-6 lg:grid-cols-3">
            <div className="card-elevated p-6">
              <h3 className="text-lg font-bold text-navy-900">Strength radar</h3>
              <p className="text-sm text-navy-500">Subject-wise average vs full marks.</p>
              {subjPerfs.length >= 3 ? (
                <div className="mt-4 flex justify-center">
                  <RadarChart
                    axes={subjPerfs.map((p) => p.subject.name)}
                    values={subjPerfs.map((p) => p.percentage)}
                    color="#2563eb"
                  />
                </div>
              ) : (
                <p className="mt-6 text-sm text-navy-400">Add at least 3 subjects to see the radar chart.</p>
              )}
            </div>

            <div className="card-elevated p-6">
              <div className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-emerald-600" />
                <h3 className="text-lg font-bold text-navy-900">Strong topics</h3>
              </div>
              <p className="mt-1 text-sm text-navy-500">Your best-performing topics.</p>
              <div className="mt-4 space-y-2.5">
                {strongTopics.slice(0, 6).map((t) => (
                  <div key={t.topic.id} className="flex items-center justify-between rounded-xl bg-emerald-50/60 px-3.5 py-2.5 ring-1 ring-emerald-100">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-navy-900">{t.topic.name}</p>
                      <p className="text-xs text-navy-500">{t.subjectName}</p>
                    </div>
                    <span className="chip bg-emerald-100 text-emerald-700">{t.percentage.toFixed(0)}%</span>
                  </div>
                ))}
                {strongTopics.length === 0 && <EmptyMini text="No strong topics yet." />}
              </div>
            </div>

            <div className="card-elevated p-6">
              <div className="flex items-center gap-2">
                <Flame className="h-5 w-5 text-rose-600" />
                <h3 className="text-lg font-bold text-navy-900">Needs improvement</h3>
              </div>
              <p className="mt-1 text-sm text-navy-500">Topics to prioritise.</p>
              <div className="mt-4 space-y-2.5">
                {weakTopics.slice(0, 6).map((t) => (
                  <div key={t.topic.id} className="flex items-center justify-between rounded-xl bg-rose-50/60 px-3.5 py-2.5 ring-1 ring-rose-100">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-navy-900">{t.topic.name}</p>
                      <p className="text-xs text-navy-500">{t.subjectName}</p>
                    </div>
                    <span className="chip bg-rose-100 text-rose-700">{t.percentage.toFixed(0)}%</span>
                  </div>
                ))}
                {weakTopics.length === 0 && <EmptyMini text="No weak topics — great work!" />}
              </div>
            </div>
          </div>

          {/* Recommended next steps */}
          <div className="mt-6 card-elevated p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Route className="h-5 w-5 text-royal-600" />
                <h3 className="text-lg font-bold text-navy-900">Recommended next steps</h3>
              </div>
              <button onClick={() => navigate("/app/path")} className="btn-soft px-3.5 py-2 text-xs">
                Full learning path <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <p className="mt-1 text-sm text-navy-500">
              Ordered by priority score — the topics with the highest score should be studied first.
            </p>
            <div className="mt-5 space-y-3">
              {recs.map((r, i) => (
                <div key={r.topicPerformance.topic.id} className="flex items-center gap-4 rounded-2xl bg-navy-50/60 px-4 py-3 ring-1 ring-navy-100">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-royal-gradient text-sm font-bold text-white">
                    {i + 1}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-navy-900">{r.topicPerformance.topic.name}</p>
                    <p className="text-xs text-navy-500">
                      {r.topicPerformance.subjectName} · {r.suggestedActivity}
                    </p>
                  </div>
                  <div className="hidden text-right sm:block">
                    <p className="text-xs font-medium text-navy-400">Score</p>
                    <p className="text-sm font-bold text-royal-700">{r.priorityScore.toFixed(1)}</p>
                  </div>
                  <span
                    className={`chip ${
                      r.priorityClass === "High"
                        ? "bg-rose-100 text-rose-700"
                        : r.priorityClass === "Medium"
                        ? "bg-amber-100 text-amber-700"
                        : "bg-emerald-100 text-emerald-700"
                    }`}
                  >
                    {r.priorityClass}
                  </span>
                </div>
              ))}
              {recs.length === 0 && <EmptyMini text="All topics complete — amazing!" />}
            </div>
          </div>

          {/* Overall progress distribution strip */}
          <div className="mt-6 card-elevated p-6">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-lg font-bold text-navy-900">Overall learning progress</h3>
              <span className="text-sm font-bold text-navy-900">{progress.toFixed(0)}%</span>
            </div>
            <ProgressBar value={progress} color="#7c3aed" height={12} />
            <p className="mt-2 text-sm text-navy-500">
              {completedTopics} of {totalTopics} topics completed across {totalSubjects} subjects.
            </p>
            <div className="mt-4">
              <StackedBar
                segments={[
                  { value: levelCounts.strong, color: "#16a34a", label: "Strong" },
                  { value: levelCounts.average, color: "#d97706", label: "Average" },
                  { value: levelCounts.needs_improvement, color: "#dc2626", label: "Needs work" },
                ]}
              />
              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs font-medium text-navy-500">
                <span><span className="text-emerald-600">●</span> Strong {levelCounts.strong}</span>
                <span><span className="text-amber-600">●</span> Average {levelCounts.average}</span>
                <span><span className="text-rose-600">●</span> Needs work {levelCounts.needs_improvement}</span>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function DistRow({ color, label, value, total }: { color: string; label: string; value: number; total: number }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs font-medium">
        <span className="text-navy-600">{label}</span>
        <span className="text-navy-900">{value} / {total}</span>
      </div>
      <ProgressBar value={total ? (value / total) * 100 : 0} color={color} height={7} />
    </div>
  );
}

function EmptyMini({ text }: { text: string }) {
  return <p className="py-3 text-center text-sm text-navy-400">{text}</p>;
}
