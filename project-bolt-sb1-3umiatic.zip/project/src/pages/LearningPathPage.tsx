import { useMemo, useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Circle,
  Filter,
  Lightbulb,
  Route,
  Sparkles,
  Target,
} from "lucide-react";
import { useApp } from "@/context/AppContext";
import { EmptyState, PageHeader } from "@/components/ui";
import { LEVEL_META } from "@/lib/performance";
import { buildLearningPath } from "@/lib/recommendations";
import { resourcesForTopic } from "@/lib/resources";
import type { Recommendation } from "@/lib/types";

type FilterMode = "all" | "high" | "medium" | "low" | "pending";

export function LearningPathPage() {
  const { subjects, navigate, loadDemoData, setSubjects } = useApp();
  const recs = useMemo(() => buildLearningPath(subjects), [subjects]);
  const [filter, setFilter] = useState<FilterMode>("all");

  const filtered = recs.filter((r) => {
    if (filter === "all") return true;
    if (filter === "pending") return !r.topicPerformance.topic.completed;
    if (filter === "high") return r.priorityClass === "High";
    if (filter === "medium") return r.priorityClass === "Medium";
    if (filter === "low") return r.priorityClass === "Low";
    return true;
  });

  function toggleComplete(subjectId: string, topicId: string, completed: boolean) {
    setSubjects(
      subjects.map((s) =>
        s.id !== subjectId
          ? s
          : {
              ...s,
              topics: s.topics.map((t) =>
                t.id === topicId ? { ...t, completed: !completed } : t
              ),
            }
      )
    );
  }

  const hasData = recs.length > 0;

  return (
    <div className="container-page py-10">
      <PageHeader
        title="Personalised Learning Path"
        subtitle="Your topics, ranked dynamically by priority score so you always know what to study next."
        icon={Route}
        actions={
          hasData ? (
            <button onClick={() => navigate("/app/progress")} className="btn-ghost px-4 py-2.5">
              <Target className="h-4 w-4" /> Track progress
            </button>
          ) : (
            <button onClick={loadDemoData} className="btn-ghost px-4 py-2.5">
              <Lightbulb className="h-4 w-4" /> Load demo data
            </button>
          )
        }
      />

      {/* Formula explainer */}
      <div className="card-elevated relative overflow-hidden p-6">
        <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-lavender-100/60 blur-2xl" />
        <div className="relative flex flex-col items-start gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-start gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-navy-gradient text-white">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-navy-900">How the priority score works</h3>
              <p className="mt-1 max-w-xl text-sm text-navy-500">
                Each topic gets a score that blends how weak the topic itself is (70%)
                with how weak its subject is (30%). The highest score is studied first.
              </p>
            </div>
          </div>
          <div className="rounded-2xl bg-navy-950 px-5 py-3.5 font-mono text-sm text-lavender-200 shadow-soft">
            Priority = 0.7 × (100 − Topic%) + 0.3 × (100 − Subject%)
          </div>
        </div>
      </div>

      {!hasData ? (
        <div className="mt-6">
          <EmptyState
            icon={Route}
            title="No learning path yet"
            description="Add your subjects and topic marks on the Performance Input page. Your personalised learning path is generated the moment your data exists."
            action={
              <div className="flex flex-wrap justify-center gap-2">
                <button onClick={() => navigate("/app/performance")} className="btn-primary px-5 py-2.5">
                  Add performance
                </button>
                <button onClick={loadDemoData} className="btn-ghost px-5 py-2.5">
                  <Lightbulb className="h-4 w-4" /> Load demo data
                </button>
              </div>
            }
          />
        </div>
      ) : (
        <>
          {/* Filters */}
          <div className="mt-6 flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 text-sm font-medium text-navy-500">
              <Filter className="h-4 w-4" /> Filter:
            </div>
            {([
              ["all", "All topics"],
              ["pending", "Not completed"],
              ["high", "High priority"],
              ["medium", "Medium priority"],
              ["low", "Low priority"],
            ] as [FilterMode, string][]).map(([mode, label]) => (
              <button
                key={mode}
                onClick={() => setFilter(mode)}
                className={`rounded-lg px-3.5 py-1.5 text-sm font-medium transition ${
                  filter === mode
                    ? "bg-royal-gradient text-white shadow-soft"
                    : "bg-white text-navy-600 ring-1 ring-navy-200 hover:bg-navy-50"
                }`}
              >
                {label}
              </button>
            ))}
            <span className="ml-auto text-sm text-navy-400">
              {filtered.length} topic{filtered.length !== 1 ? "s" : ""}
            </span>
          </div>

          {/* Path list */}
          <div className="mt-5 space-y-4">
            {filtered.length === 0 && (
              <p className="card-elevated px-6 py-10 text-center text-sm text-navy-400">
                No topics match this filter.
              </p>
            )}
            {filtered.map((r, i) => (
              <PathCard
                key={r.topicPerformance.topic.id}
                rank={i + 1}
                rec={r}
                onToggleComplete={() =>
                  toggleComplete(
                    r.topicPerformance.subjectId,
                    r.topicPerformance.topic.id,
                    r.topicPerformance.topic.completed
                  )
                }
                onViewResources={() => navigate("/app/resources")}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function PathCard({
  rank,
  rec,
  onToggleComplete,
  onViewResources,
}: {
  rank: number;
  rec: Recommendation;
  onToggleComplete: () => void;
  onViewResources: () => void;
}) {
  const tp = rec.topicPerformance;
  const meta = LEVEL_META[tp.level];
  const done = tp.topic.completed;
  const classColor =
    rec.priorityClass === "High"
      ? "#dc2626"
      : rec.priorityClass === "Medium"
      ? "#d97706"
      : "#16a34a";
  const classBg =
    rec.priorityClass === "High"
      ? "bg-rose-50 text-rose-700 ring-rose-200"
      : rec.priorityClass === "Medium"
      ? "bg-amber-50 text-amber-700 ring-amber-200"
      : "bg-emerald-50 text-emerald-700 ring-emerald-200";
  const matched = resourcesForTopic(tp.subjectName, tp.topic.name);

  return (
    <div
      className={`card-elevated overflow-hidden transition ${
        done ? "opacity-70" : ""
      }`}
    >
      <div className="flex flex-col gap-4 p-5 lg:flex-row lg:items-center">
        {/* Rank badge + connector */}
        <div className="flex items-center gap-3 lg:w-32 lg:flex-col lg:items-center lg:gap-2">
          <div
            className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-base font-extrabold text-white shadow-soft"
            style={{ background: classColor }}
          >
            {rank}
          </div>
          <div className="lg:text-center">
            <p className="text-xs font-medium text-navy-400">Priority</p>
            <p className="text-sm font-bold text-navy-900">{rec.priorityScore.toFixed(1)}</p>
          </div>
        </div>

        {/* Main content */}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className={`text-base font-bold text-navy-900 ${done ? "line-through" : ""}`}>
              {tp.topic.name}
            </h3>
            <span className={`chip ${meta.bg} ${meta.text} ring-1 ${meta.ring}`}>{meta.label}</span>
            <span className={`chip ring-1 ${classBg}`}>{rec.priorityClass} priority</span>
            {done && (
              <span className="chip bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200">
                <CheckCircle2 className="h-3 w-3" /> Completed
              </span>
            )}
          </div>
          <p className="mt-1 text-xs text-navy-500">{tp.subjectName}</p>
          <div className="mt-3 rounded-xl bg-navy-50/70 p-3 ring-1 ring-navy-100">
            <p className="text-xs font-semibold uppercase tracking-wide text-royal-700">Suggested activity</p>
            <p className="mt-0.5 text-sm text-navy-700">{rec.suggestedActivity}</p>
          </div>
          {matched.length > 0 && (
            <p className="mt-2 text-xs text-navy-500">
              {matched.length} resource{matched.length !== 1 ? "s" : ""} available — visit the Resources page.
            </p>
          )}
        </div>

        {/* Stats + actions */}
        <div className="flex items-center gap-4 lg:flex-col lg:items-end lg:gap-3">
          <div className="text-right">
            <p className="text-xs font-medium text-navy-400">Performance</p>
            <p className="text-lg font-bold text-navy-900">{tp.percentage.toFixed(0)}%</p>
          </div>
          <button
            onClick={onToggleComplete}
            className={`btn px-4 py-2.5 text-sm ${
              done
                ? "btn-ghost"
                : "bg-emerald-500 text-white hover:bg-emerald-600 shadow-soft"
            }`}
          >
            {done ? (
              <>
                <Circle className="h-4 w-4" /> Mark pending
              </>
            ) : (
              <>
                <CheckCircle2 className="h-4 w-4" /> Mark done
              </>
            )}
          </button>
          <button onClick={onViewResources} className="btn-soft px-4 py-2.5 text-sm">
            Resources <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
