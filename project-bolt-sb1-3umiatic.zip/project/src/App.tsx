import { AppProvider, useApp } from "@/context/AppContext";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { RequireAuth } from "@/components/RequireAuth";
import { Navigate } from "@/components/Navigate";
import { LandingPage } from "@/pages/LandingPage";
import { LoginPage, RegisterPage } from "@/pages/AuthPages";
import { DashboardPage } from "@/pages/DashboardPage";
import { PerformancePage } from "@/pages/PerformancePage";
import { AnalysisPage } from "@/pages/AnalysisPage";
import { LearningPathPage } from "@/pages/LearningPathPage";
import { ResourcesPage } from "@/pages/ResourcesPage";
import { ProgressPage } from "@/pages/ProgressPage";

function Router() {
  const { route } = useApp();

  // Strip in-page anchor (e.g. "/#features" -> "/")
  const cleanRoute = route.split("#")[0] || "/";

  let page;
  switch (cleanRoute) {
    case "/":
      page = <LandingPage />;
      break;
    case "/login":
      page = <LoginPage />;
      break;
    case "/register":
      page = <RegisterPage />;
      break;
    case "/app":
      page = (
        <RequireAuth>
          <DashboardPage />
        </RequireAuth>
      );
      break;
    case "/app/performance":
      page = (
        <RequireAuth>
          <PerformancePage />
        </RequireAuth>
      );
      break;
    case "/app/analysis":
      page = (
        <RequireAuth>
          <AnalysisPage />
        </RequireAuth>
      );
      break;
    case "/app/path":
      page = (
        <RequireAuth>
          <LearningPathPage />
        </RequireAuth>
      );
      break;
    case "/app/resources":
      page = (
        <RequireAuth>
          <ResourcesPage />
        </RequireAuth>
      );
      break;
    case "/app/progress":
      page = (
        <RequireAuth>
          <ProgressPage />
        </RequireAuth>
      );
      break;
    default:
      page = <Navigate to="/" />;
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">{page}</main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <Router />
    </AppProvider>
  );
}

export default App;
